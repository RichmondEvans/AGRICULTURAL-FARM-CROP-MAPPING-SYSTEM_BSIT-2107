
package com.example.agricultural

import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.agricultural.databinding.ActivityFarmBusinessBinding
import kotlinx.coroutines.launch
import java.util.Locale

class FarmBusinessActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFarmBusinessBinding

    private val dao by lazy {
        AppDatabase.get(this).farmDao()
    }

    private var farmId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFarmBusinessBinding.inflate(layoutInflater)
        setContentView(binding.root)

        farmId = intent.getIntExtra("farm_id", -1)

        if (farmId <= 0) {
            Toast.makeText(this, "Invalid Farm ID", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSaveBusiness.setOnClickListener { saveBusiness() }

        loadBusiness()
    }

    private fun saveBusiness() {

        val crop = binding.etBusinessCropName.text.toString().trim()
        val quantity = binding.etQuantitySold.text.toString().trim().toDoubleOrNull()
        val price = binding.etPrice.text.toString().trim().toDoubleOrNull()
        val expenses = binding.etExpenses.text.toString().trim().toDoubleOrNull()

        if (
            crop.isBlank() ||
            quantity == null ||
            price == null ||
            expenses == null ||
            quantity < 0 ||
            price < 0 ||
            expenses < 0
        ) {
            Toast.makeText(
                this,
                "Please enter valid information",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        lifecycleScope.launch {
            try {

                dao.insertBusiness(
                    FarmBusiness(
                        farmId = farmId,
                        cropName = crop,
                        quantitySold = quantity,
                        price = price,
                        expenses = expenses
                    )
                )

                binding.etBusinessCropName.text.clear()
                binding.etQuantitySold.text.clear()
                binding.etPrice.text.clear()
                binding.etExpenses.text.clear()

                loadBusiness()

                Toast.makeText(
                    this@FarmBusinessActivity,
                    "Business record saved!",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (e: Exception) {
                Toast.makeText(
                    this@FarmBusinessActivity,
                    "Save failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun loadBusiness() {

        lifecycleScope.launch {
            try {

                val records = dao.getBusiness(farmId)

                binding.layoutBusinessList.removeAllViews()

                var sales = 0.0
                var expenses = 0.0

                if (records.isEmpty()) {
                    val empty = TextView(this@FarmBusinessActivity)
                    empty.text = "No business records available."
                    empty.textSize = 15f
                    empty.gravity = Gravity.CENTER
                    empty.setTextColor(Color.GRAY)
                    empty.setPadding(20, 35, 20, 35)
                    binding.layoutBusinessList.addView(empty)
                }

                records.forEach { record ->

                    val recordSales = record.quantitySold * record.price
                    val profit = recordSales - record.expenses

                    sales += recordSales
                    expenses += record.expenses

                    val card = LinearLayout(this@FarmBusinessActivity)
                    card.orientation = LinearLayout.VERTICAL
                    card.setPadding(20, 18, 20, 18)
                    card.setBackgroundColor(Color.rgb(240, 248, 240))

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 8, 0, 12)
                    card.layoutParams = params

                    val title = TextView(this@FarmBusinessActivity)
                    title.text = record.cropName
                    title.textSize = 19f
                    title.setTypeface(null, Typeface.BOLD)
                    title.setTextColor(Color.rgb(35, 100, 55))
                    card.addView(title)

                    val quantity = TextView(this@FarmBusinessActivity)
                    quantity.text = "Quantity Sold: ${record.quantitySold}"
                    quantity.textSize = 15f
                    quantity.setTextColor(Color.DKGRAY)
                    quantity.setPadding(0, 8, 0, 0)
                    card.addView(quantity)

                    val price = TextView(this@FarmBusinessActivity)
                    price.text = "Price per Unit: ${money(record.price)}"
                    price.textSize = 15f
                    price.setTextColor(Color.DKGRAY)
                    price.setPadding(0, 5, 0, 0)
                    card.addView(price)

                    val totalSales = TextView(this@FarmBusinessActivity)
                    totalSales.text = "Sales: ${money(recordSales)}"
                    totalSales.textSize = 15f
                    totalSales.setTextColor(Color.DKGRAY)
                    totalSales.setPadding(0, 5, 0, 0)
                    card.addView(totalSales)

                    val totalExpenses = TextView(this@FarmBusinessActivity)
                    totalExpenses.text = "Expenses: ${money(record.expenses)}"
                    totalExpenses.textSize = 15f
                    totalExpenses.setTextColor(Color.DKGRAY)
                    totalExpenses.setPadding(0, 5, 0, 0)
                    card.addView(totalExpenses)

                    val totalProfit = TextView(this@FarmBusinessActivity)
                    totalProfit.text = "Profit: ${money(profit)}"
                    totalProfit.textSize = 17f
                    totalProfit.setTypeface(null, Typeface.BOLD)
                    totalProfit.setTextColor(
                        if (profit >= 0) Color.rgb(35, 130, 65)
                        else Color.RED
                    )
                    totalProfit.setPadding(0, 5, 0, 12)
                    card.addView(totalProfit)

                    val delete = Button(this@FarmBusinessActivity)
                    delete.text = "Delete Record"

                    delete.setOnClickListener {
                        lifecycleScope.launch {
                            try {
                                dao.deleteBusiness(record.businessId)
                                loadBusiness()

                                Toast.makeText(
                                    this@FarmBusinessActivity,
                                    "Business record deleted",
                                    Toast.LENGTH_SHORT
                                ).show()

                            } catch (e: Exception) {
                                Toast.makeText(
                                    this@FarmBusinessActivity,
                                    "Delete failed: ${e.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }

                    card.addView(delete)
                    binding.layoutBusinessList.addView(card)
                }

                binding.tvTotalSales.text =
                    "Total Sales: ${money(sales)}"

                binding.tvTotalExpenses.text =
                    "Total Expenses: ${money(expenses)}"

                binding.tvTotalProfit.text =
                    "Total Profit: ${money(sales - expenses)}"

                binding.tvTotalProfit.setTextColor(
                    if (sales - expenses >= 0) Color.rgb(35, 130, 65)
                    else Color.RED
                )

            } catch (e: Exception) {
                Toast.makeText(
                    this@FarmBusinessActivity,
                    "Loading failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun money(amount: Double): String {
        return "₱" + String.format(Locale.US, "%,.2f", amount)
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && farmId > 0) {
            loadBusiness()
        }
    }
}
