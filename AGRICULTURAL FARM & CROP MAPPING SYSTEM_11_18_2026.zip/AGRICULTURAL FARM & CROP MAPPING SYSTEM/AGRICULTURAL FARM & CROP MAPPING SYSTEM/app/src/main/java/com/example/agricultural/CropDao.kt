
package com.example.agricultural

import android.content.ContentValues

class CropDao(private val dbHelper: AppDatabase) {

    fun insert(crop: Crop): Long {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put("farmId", crop.farmId)
            put("cropName", crop.cropName)
            put("cropVariety", crop.cropVariety)
            put("cropStatus", crop.cropStatus)
        }

        return db.insert("crops", null, values)
    }

    fun getAll(): List<Crop> {
        val crops = mutableListOf<Crop>()

        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM crops ORDER BY cropId ASC",
            null
        )

        cursor.use {
            while (it.moveToNext()) {
                crops.add(
                    Crop(
                        cropId = it.getInt(it.getColumnIndexOrThrow("cropId")),
                        farmId = it.getInt(it.getColumnIndexOrThrow("farmId")),
                        cropName = it.getString(it.getColumnIndexOrThrow("cropName")),
                        cropVariety = it.getString(it.getColumnIndexOrThrow("cropVariety")),
                        cropStatus = it.getString(it.getColumnIndexOrThrow("cropStatus"))
                    )
                )
            }
        }

        return crops
    }

    fun getByFarmId(farmId: Int): List<Crop> {
        val crops = mutableListOf<Crop>()

        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM crops WHERE farmId = ?",
            arrayOf(farmId.toString())
        )

        cursor.use {
            while (it.moveToNext()) {
                crops.add(
                    Crop(
                        cropId = it.getInt(it.getColumnIndexOrThrow("cropId")),
                        farmId = it.getInt(it.getColumnIndexOrThrow("farmId")),
                        cropName = it.getString(it.getColumnIndexOrThrow("cropName")),
                        cropVariety = it.getString(it.getColumnIndexOrThrow("cropVariety")),
                        cropStatus = it.getString(it.getColumnIndexOrThrow("cropStatus"))
                    )
                )
            }
        }

        return crops
    }

    // GET CROP BY ID
    fun getById(cropId: Int): Crop? {
        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM crops WHERE cropId = ?",
            arrayOf(cropId.toString())
        )

        cursor.use {
            if (it.moveToFirst()) {
                return Crop(
                    cropId = it.getInt(it.getColumnIndexOrThrow("cropId")),
                    farmId = it.getInt(it.getColumnIndexOrThrow("farmId")),
                    cropName = it.getString(it.getColumnIndexOrThrow("cropName")),
                    cropVariety = it.getString(it.getColumnIndexOrThrow("cropVariety")),
                    cropStatus = it.getString(it.getColumnIndexOrThrow("cropStatus"))
                )
            }
        }

        return null
    }
}
