
package com.example.agricultural

import android.content.ContentValues

class ProductionAreaDao(private val dbHelper: AppDatabase) {

    // INSERT PRODUCTION AREA
    fun insert(area: ProductionArea): Long {
        val values = ContentValues().apply {
            put("farmId", area.farmId)
            put("areaUnit", area.areaUnit)
            put("soilType", area.soilType)
            put("currentLandStatus", area.currentLandStatus)
        }

        return dbHelper.writableDatabase.insert(
            "production_areas",
            null,
            values
        )
    }

    // GET ALL PRODUCTION AREAS
    fun getAll(): List<ProductionArea> {
        val areas = mutableListOf<ProductionArea>()

        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM production_areas ORDER BY areaId ASC",
            null
        )

        cursor.use {
            while (it.moveToNext()) {
                areas.add(
                    ProductionArea(
                        areaId = it.getInt(it.getColumnIndexOrThrow("areaId")),
                        farmId = it.getInt(it.getColumnIndexOrThrow("farmId")),
                        areaUnit = it.getString(it.getColumnIndexOrThrow("areaUnit")),
                        soilType = it.getString(it.getColumnIndexOrThrow("soilType")),
                        currentLandStatus = it.getString(it.getColumnIndexOrThrow("currentLandStatus"))
                    )
                )
            }
        }

        return areas
    }

    // GET PRODUCTION AREA BY FARM ID
    fun getByFarmId(farmId: Int): List<ProductionArea> {
        val areas = mutableListOf<ProductionArea>()

        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM production_areas WHERE farmId = ?",
            arrayOf(farmId.toString())
        )

        cursor.use {
            while (it.moveToNext()) {
                areas.add(
                    ProductionArea(
                        areaId = it.getInt(it.getColumnIndexOrThrow("areaId")),
                        farmId = it.getInt(it.getColumnIndexOrThrow("farmId")),
                        areaUnit = it.getString(it.getColumnIndexOrThrow("areaUnit")),
                        soilType = it.getString(it.getColumnIndexOrThrow("soilType")),
                        currentLandStatus = it.getString(it.getColumnIndexOrThrow("currentLandStatus"))
                    )
                )
            }
        }

        return areas
    }

    // GET PRODUCTION AREA BY ID
    fun getById(areaId: Int): ProductionArea? {
        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM production_areas WHERE areaId = ?",
            arrayOf(areaId.toString())
        )

        cursor.use {
            if (it.moveToFirst()) {
                return ProductionArea(
                    areaId = it.getInt(it.getColumnIndexOrThrow("areaId")),
                    farmId = it.getInt(it.getColumnIndexOrThrow("farmId")),
                    areaUnit = it.getString(it.getColumnIndexOrThrow("areaUnit")),
                    soilType = it.getString(it.getColumnIndexOrThrow("soilType")),
                    currentLandStatus = it.getString(it.getColumnIndexOrThrow("currentLandStatus"))
                )
            }
        }

        return null
    }
}
