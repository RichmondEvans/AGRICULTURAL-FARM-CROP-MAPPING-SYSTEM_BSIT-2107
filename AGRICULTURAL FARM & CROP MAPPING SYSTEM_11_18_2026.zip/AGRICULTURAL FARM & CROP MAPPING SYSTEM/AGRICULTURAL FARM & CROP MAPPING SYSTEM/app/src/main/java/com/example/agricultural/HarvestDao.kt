
package com.example.agricultural

import android.content.ContentValues

class HarvestDao(private val dbHelper: AppDatabase) {

    // INSERT HARVEST
    fun insert(harvest: Harvest): Long {
        val values = ContentValues().apply {
            put("cropId", harvest.cropId)
            put("harvestDate", harvest.harvestDate)
            put("harvestQuality", harvest.harvestQuality)
            put("availableQuantity", harvest.availableQuantity)
        }

        return dbHelper.writableDatabase.insert(
            "harvests",
            null,
            values
        )
    }

    // GET ALL HARVESTS
    fun getAll(): List<Harvest> {
        val harvests = mutableListOf<Harvest>()

        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM harvests ORDER BY harvestId ASC",
            null
        )

        cursor.use {
            while (it.moveToNext()) {
                harvests.add(
                    Harvest(
                        harvestId = it.getInt(it.getColumnIndexOrThrow("harvestId")),
                        cropId = it.getInt(it.getColumnIndexOrThrow("cropId")),
                        harvestDate = it.getString(it.getColumnIndexOrThrow("harvestDate")),
                        harvestQuality = it.getString(it.getColumnIndexOrThrow("harvestQuality")),
                        availableQuantity = it.getDouble(it.getColumnIndexOrThrow("availableQuantity"))
                    )
                )
            }
        }

        return harvests
    }

    // GET HARVEST BY CROP ID
    fun getByCropId(cropId: Int): List<Harvest> {
        val harvests = mutableListOf<Harvest>()

        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM harvests WHERE cropId = ?",
            arrayOf(cropId.toString())
        )

        cursor.use {
            while (it.moveToNext()) {
                harvests.add(
                    Harvest(
                        harvestId = it.getInt(it.getColumnIndexOrThrow("harvestId")),
                        cropId = it.getInt(it.getColumnIndexOrThrow("cropId")),
                        harvestDate = it.getString(it.getColumnIndexOrThrow("harvestDate")),
                        harvestQuality = it.getString(it.getColumnIndexOrThrow("harvestQuality")),
                        availableQuantity = it.getDouble(it.getColumnIndexOrThrow("availableQuantity"))
                    )
                )
            }
        }

        return harvests
    }

    // GET HARVEST BY ID
    fun getById(harvestId: Int): Harvest? {
        val cursor = dbHelper.readableDatabase.rawQuery(
            "SELECT * FROM harvests WHERE harvestId = ?",
            arrayOf(harvestId.toString())
        )

        cursor.use {
            if (it.moveToFirst()) {
                return Harvest(
                    harvestId = it.getInt(it.getColumnIndexOrThrow("harvestId")),
                    cropId = it.getInt(it.getColumnIndexOrThrow("cropId")),
                    harvestDate = it.getString(it.getColumnIndexOrThrow("harvestDate")),
                    harvestQuality = it.getString(it.getColumnIndexOrThrow("harvestQuality")),
                    availableQuantity = it.getDouble(it.getColumnIndexOrThrow("availableQuantity"))
                )
            }
        }

        return null
    }
}
