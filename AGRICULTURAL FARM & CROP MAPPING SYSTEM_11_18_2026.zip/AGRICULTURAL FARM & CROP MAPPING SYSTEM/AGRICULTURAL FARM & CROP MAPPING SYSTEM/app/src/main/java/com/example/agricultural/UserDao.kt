
package com.example.agricultural

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UserDao(private val dbHelper: AppDatabase) {

    fun register(
        fullName: String,
        email: String,
        passwordHash: String
    ): Long {

        val values = ContentValues().apply {
            put("fullName", fullName.trim())
            put("email", email.trim())
            put("passwordHash", passwordHash)
            put(
                "createdAt",
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss",
                    Locale.getDefault()
                ).format(Date())
            )
        }

        return dbHelper.writableDatabase.insert(
            "users",
            null,
            values
        )
    }

    fun getByEmail(email: String): User? {

        val cursor = dbHelper.readableDatabase.query(
            "users",
            null,
            "email = ?",
            arrayOf(email.trim()),
            null,
            null,
            null
        )

        cursor.use {
            if (it.moveToFirst()) {
                return User(
                    id = it.getInt(it.getColumnIndexOrThrow("id")),
                    fullName = it.getString(
                        it.getColumnIndexOrThrow("fullName")
                    ),
                    email = it.getString(
                        it.getColumnIndexOrThrow("email")
                    ),
                    passwordHash = it.getString(
                        it.getColumnIndexOrThrow("passwordHash")
                    ),
                    createdAt = it.getString(
                        it.getColumnIndexOrThrow("createdAt")
                    )
                )
            }
        }

        return null
    }

    fun getById(id: Int): User? {

        val cursor = dbHelper.readableDatabase.query(
            "users",
            null,
            "id = ?",
            arrayOf(id.toString()),
            null,
            null,
            null
        )

        cursor.use {
            if (it.moveToFirst()) {
                return User(
                    id = it.getInt(it.getColumnIndexOrThrow("id")),
                    fullName = it.getString(
                        it.getColumnIndexOrThrow("fullName")
                    ),
                    email = it.getString(
                        it.getColumnIndexOrThrow("email")
                    ),
                    passwordHash = it.getString(
                        it.getColumnIndexOrThrow("passwordHash")
                    ),
                    createdAt = it.getString(
                        it.getColumnIndexOrThrow("createdAt")
                    )
                )
            }
        }

        return null
    }

    fun updateProfile(
        id: Int,
        fullName: String,
        email: String
    ): Boolean {

        val values = ContentValues().apply {
            put("fullName", fullName.trim())
            put("email", email.trim())
        }

        return try {
            dbHelper.writableDatabase.update(
                "users",
                values,
                "id = ?",
                arrayOf(id.toString())
            ) > 0
        } catch (e: android.database.sqlite.SQLiteConstraintException) {
            false
        }
    }
}
