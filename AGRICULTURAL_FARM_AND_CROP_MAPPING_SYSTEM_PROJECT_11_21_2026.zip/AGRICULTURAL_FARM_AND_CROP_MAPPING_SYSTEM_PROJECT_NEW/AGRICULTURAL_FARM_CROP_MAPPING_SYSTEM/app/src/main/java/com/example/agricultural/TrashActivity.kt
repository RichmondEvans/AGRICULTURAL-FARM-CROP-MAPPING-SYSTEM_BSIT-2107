package com.example.agricultural

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class TrashActivity : BaseActivity() {

    private val farmRepository: FarmRepository by lazy { database.farmDao() }

    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Recycle Bin"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        }

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val back = Button(this).apply {
            text = "Back"
            setOnClickListener { finish() }
        }

        root.addView(title)
        root.addView(list)
        root.addView(back)

        setContentView(ScrollView(this).apply { addView(root) })

        loadTrash()
    }

    private fun loadTrash() {
        launchSafely("Failed to load recycle bin") {
            // Sariling mga na-delete na farm lang ang makikita
            val farms = farmRepository.getTrashFarms().filter { accessPolicy.canEdit(it) }
            list.removeAllViews()

            if (farms.isEmpty()) {
                val empty = TextView(this@TrashActivity)
                empty.text = "Recycle Bin is empty."
                empty.setPadding(0, 40, 0, 40)
                list.addView(empty)
            }

            farms.forEach { farm ->
                list.addView(makeCard(farm))
            }
        }
    }

    private fun makeCard(farm: Farm): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(20, 18, 20, 18)
        card.setBackgroundColor(Color.rgb(240, 248, 240))

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 8, 0, 12)
        card.layoutParams = params

        val name = TextView(this)
        name.text = farm.farmName
        name.textSize = 19f
        name.setTypeface(null, Typeface.BOLD)
        card.addView(name)

        val address = TextView(this)
        address.text = farm.farmAddress
        address.setPadding(0, 6, 0, 12)
        card.addView(address)

        val restore = Button(this)
        restore.text = "Restore"
        restore.setOnClickListener {
            launchSafely("Restore failed") {
                farmRepository.restoreFarm(farm.id)
                toast("Farm restored")
                loadTrash()
            }
        }
        card.addView(restore)

        val deleteForever = Button(this)
        deleteForever.text = "Delete Forever"
        deleteForever.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Delete Forever")
                .setMessage("The farm and its records will be deleted permanently.")
                .setPositiveButton("Delete") { _, _ ->
                    launchSafely("Delete failed") {
                        farmRepository.delete(farm.id)
                        loadTrash()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        card.addView(deleteForever)

        return card
    }
}