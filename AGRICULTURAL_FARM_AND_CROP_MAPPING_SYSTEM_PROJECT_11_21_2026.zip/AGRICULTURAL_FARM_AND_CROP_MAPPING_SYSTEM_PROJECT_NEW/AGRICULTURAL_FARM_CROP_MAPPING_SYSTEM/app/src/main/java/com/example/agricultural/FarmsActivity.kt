package com.example.agricultural

import android.content.Intent
import android.os.Bundle
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.agricultural.databinding.ActivityFarmsBinding

// FARM LIST SCREEN
class FarmsActivity : BaseActivity() {

    private lateinit var binding: ActivityFarmsBinding

    private val farmRepository: FarmRepository by lazy { database.farmDao() }

    private val adapter = FarmAdapter { farm ->
        val intent = Intent(this, FarmDetailsActivity::class.java)
        intent.putExtra(FarmScopedActivity.EXTRA_FARM_ID, farm.id)
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFarmsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvFarms.layoutManager = LinearLayoutManager(this)
        binding.rvFarms.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }

        binding.etSearch.doAfterTextChanged { text ->
            loadFarms(text?.toString()?.trim().orEmpty())
        }

        loadFarms("")
    }

    private fun loadFarms(query: String) {
        launchSafely("Failed to load farms") {
            val farms = if (query.isBlank()) {
                farmRepository.getAll()
            } else {
                farmRepository.search(query)
            }

            adapter.submitList(farms)
            binding.tvFarmCount.text = "${farms.size} Registered Farms"
        }
    }
}