package com.example.agricultural

import android.content.Intent
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import com.example.agricultural.databinding.ActivityLoginBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : BaseActivity() {

    private lateinit var binding: ActivityLoginBinding

    private val userDao: UserDataSource by lazy { database.userDao() }

    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sessionManager = SessionManager(this)

        if (sessionManager.isLoggedIn()) {
            openHome()
            return
        }

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            loginUser()
        }

        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun loginUser() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()

        if (email.isEmpty() || password.isEmpty()) {
            toast("Please enter your email and password")
            return
        }

        binding.btnLogin.isEnabled = false

        lifecycleScope.launch {
            try {
                val user = withContext(Dispatchers.IO) {
                    userDao.getByEmail(email)
                }

                if (user != null &&
                    PasswordHasher.verify(password, user.passwordHash)
                ) {
                    sessionManager.saveLogin(user.id)
                    toast("Welcome, ${user.fullName}!")
                    openHome()
                } else {
                    toast("Invalid email or password")
                }

            } catch (e: Exception) {
                toast("Login error: ${e.message}", long = true)
            } finally {
                binding.btnLogin.isEnabled = true
            }
        }
    }

    private fun openHome() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        startActivity(intent)
        finish()
    }
}