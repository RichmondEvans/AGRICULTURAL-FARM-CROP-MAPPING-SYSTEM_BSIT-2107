package com.example.agricultural

enum class FarmRole { OWNER, VIEWER }

class FarmAccessPolicy(private val currentUserId: Int) {

    fun roleFor(farm: Farm): FarmRole =
        if (farm.isOwnedBy(currentUserId)) FarmRole.OWNER else FarmRole.VIEWER

    fun canEdit(farm: Farm): Boolean = roleFor(farm) == FarmRole.OWNER
}