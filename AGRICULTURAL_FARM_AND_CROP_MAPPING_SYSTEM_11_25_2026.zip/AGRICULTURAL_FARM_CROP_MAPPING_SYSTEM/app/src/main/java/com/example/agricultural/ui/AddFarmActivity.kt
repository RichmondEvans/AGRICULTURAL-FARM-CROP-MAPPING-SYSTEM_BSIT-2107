package com.example.agricultural.ui
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import com.example.agricultural.databinding.ActivityAddFarmBinding
import com.example.agricultural.model.*
import com.example.agricultural.repository.*
class AddFarmActivity : BaseActivity() {

    private lateinit var binding: ActivityAddFarmBinding
    private val farmRepository: FarmRepository by lazy { database.farmDao() }
    private var selectedFarmPhoto: Uri? = null

    // ================
    // PHOTO PICKER
    // ================
    private val photoPicker =
        registerForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )

                    selectedFarmPhoto = uri
                    binding.imgFarmPhoto.setImageURI(uri)
                    toast("Farm photo selected successfully")

                } catch (e: Exception) {
                    selectedFarmPhoto = null
                    toast("Unable to access photo: ${e.message}", long = true)
                }
            }
        }

    // ============
    // ON CREATE
    // ============
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddFarmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnChoosePhoto.setOnClickListener {
            photoPicker.launch(arrayOf("image/*"))
        }

        binding.btnSave.setOnClickListener {
            saveFarm()
        }
    }

    // ============
    // SAVE FARM
    // ============
    private fun saveFarm() {
        val name = binding.etFarmName.text.toString().trim()
        val owner = binding.etOwnerName.text.toString().trim()
        val address = binding.etAddress.text.toString().trim()
        val contact = binding.etContact.text.toString().trim()
        val lat = binding.etLatitude.text.toString().trim().toDoubleOrNull()
        val lng = binding.etLongitude.text.toString().trim().toDoubleOrNull()

        // Valid farm details
        if (name.isEmpty() || owner.isEmpty() || address.isEmpty() || contact.isEmpty()) {
            toast("Please fill in all farm details")
            return
        }

        // Valid coordinates
        if (
            lat == null ||
            lng == null ||
            lat !in -90.0..90.0 ||
            lng !in -180.0..180.0
        ) {
            toast("Enter valid latitude and longitude")
            return
        }

        launchSafely("Unable to save farm") {
            val farm = Farm(
                farmName = name,
                ownerName = owner,
                farmAddress = address,
                contactNumber = contact,
                latitude = lat,
                longitude = lng,
                farmPhoto = selectedFarmPhoto?.toString() ?: "",
                ownerUserId = currentUserId
            )

            farmRepository.insert(farm)

            toast("Farm saved successfully!")
            finish()
        }
    }
}
