package com.example.agricultural.ui
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import com.example.agricultural.database.*
import com.example.agricultural.utils.*

abstract class BaseActivity : AppCompatActivity() {


    protected val database: AppDatabase by lazy { AppDatabase.get(this) }

    protected fun toast(message: String, long: Boolean = false) {
        Toast.makeText(
            this,
            message,
            if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
        ).show()
    }

    protected val currentUserId: Int by lazy { SessionManager(this).getUserId() }
    protected val accessPolicy: FarmAccessPolicy by lazy { FarmAccessPolicy(currentUserId) }

    protected fun launchSafely(
        errorPrefix: String,
        block: suspend CoroutineScope.() -> Unit
    ): Job = lifecycleScope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            toast("$errorPrefix: ${e.message}", long = true)
        }
    }
}
