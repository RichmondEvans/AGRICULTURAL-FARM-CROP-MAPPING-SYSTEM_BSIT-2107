package com.example.agricultural.dao
import android.content.ContentValues
import android.database.Cursor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.agricultural.model.*
import com.example.agricultural.repository.*
import com.example.agricultural.database.*

abstract class BaseDao<Record : AgriculturalRecord>(
    protected val helper: AppDatabase,
    private val table: String,
    private val idColumn: String
) : ReadRepository<Record>, WriteRepository<Record> {

    protected abstract fun toValues(item: Record): ContentValues

    protected abstract fun fromCursor(cursor: Cursor): Record

    protected open val selectSql: String
        get() = "SELECT * FROM $table"

    protected open val orderBy: String
        get() = "$idColumn ASC"

    protected suspend fun <R> io(block: () -> R): R =
        withContext(Dispatchers.IO) { block() }

    protected fun query(sql: String, args: Array<String>? = null): List<Record> {
        val result = mutableListOf<Record>()
        helper.readableDatabase.rawQuery(sql, args).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(fromCursor(cursor))
            }
        }
        return result
    }

    override suspend fun insert(item: Record): Long = io {
        helper.writableDatabase.insertOrThrow(table, null, toValues(item))
    }

    override suspend fun update(item: Record): Int = io {
        helper.writableDatabase.update(
            table,
            toValues(item),
            "$idColumn = ?",
            arrayOf(item.id.toString())
        )
    }

    override suspend fun delete(id: Int): Int = io {
        helper.writableDatabase.delete(
            table,
            "$idColumn = ?",
            arrayOf(id.toString())
        )
    }

    override suspend fun getById(id: Int): Record? = io {
        query("$selectSql WHERE $idColumn = ?", arrayOf(id.toString()))
            .firstOrNull()
    }

    override suspend fun getAll(): List<Record> = io {
        query("$selectSql ORDER BY $orderBy")
    }
}

abstract class FarmScopedDao<Record : AgriculturalRecord>(
    helper: AppDatabase,
    table: String,
    idColumn: String
) : BaseDao<Record>(helper, table, idColumn), FarmScopedRepository<Record> {

    protected open val farmColumn: String
        get() = "farmId"

    override suspend fun getByFarmId(farmId: Int): List<Record> = io {
        query(
            "$selectSql WHERE $farmColumn = ? ORDER BY $orderBy",
            arrayOf(farmId.toString())
        )
    }
}

// ---- Small cursor helpers (read a column by name) ----

internal fun Cursor.int(column: String): Int =
    getInt(getColumnIndexOrThrow(column))

internal fun Cursor.double(column: String): Double =
    getDouble(getColumnIndexOrThrow(column))

internal fun Cursor.string(column: String): String =
    getString(getColumnIndexOrThrow(column)) ?: ""
