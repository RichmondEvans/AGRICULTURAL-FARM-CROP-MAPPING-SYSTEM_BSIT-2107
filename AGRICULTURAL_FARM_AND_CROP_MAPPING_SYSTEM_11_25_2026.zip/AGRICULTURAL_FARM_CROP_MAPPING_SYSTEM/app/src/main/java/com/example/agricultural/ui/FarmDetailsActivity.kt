package com.example.agricultural.ui
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.example.agricultural.databinding.ActivityFarmDetailsBinding
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polygon
import com.example.agricultural.repository.*

class FarmDetailsActivity : FarmScopedActivity() {

    private lateinit var binding: ActivityFarmDetailsBinding
    private lateinit var farmMap: MapView

    private val farmRepository: FarmRepository by lazy { database.farmDao() }
    private val boundaryRepository: BoundaryRepository by lazy { database.boundaryDao() }

    private val boundaryOverlays = mutableListOf<Overlay>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        if (!resolveFarmId()) return

        Configuration.getInstance().userAgentValue = packageName

        binding = ActivityFarmDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize OpenStreetMap
        farmMap = binding.farmMap
        farmMap.setMultiTouchControls(true)
        farmMap.setUseDataConnection(true)

        // Back button
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnDeleteFarm.setOnClickListener {
            confirmDeleteFarm()
        }

        // Farm management modules
        binding.cardCrops.setOnClickListener {
            openModule(CropsActivity::class.java)
        }

        binding.cardAreas.setOnClickListener {
            openModule(ProductionAreaActivity::class.java)
        }

        binding.cardHarvest.setOnClickListener {
            openModule(HarvestActivity::class.java)
        }

        binding.cardBusiness.setOnClickListener {
            openModule(FarmBusinessActivity::class.java)
        }

        binding.btnDrawCropAreas.setOnClickListener {
            openModule(CropAreaActivity::class.java)
        }

        loadFarmDetails()
    }

    private fun openModule(activity: Class<*>) {
        try {
            val moduleIntent = Intent(this, activity)
            moduleIntent.putExtra(EXTRA_FARM_ID, farmId)
            startActivity(moduleIntent)

        } catch (e: Exception) {
            toast("Unable to open module: ${e.message}", long = true)
        }
    }

    // Load farm information from SQLite
    private fun loadFarmDetails() {
        launchSafely("Unable to load farm details") {
            val farm = farmRepository.getById(farmId)

            if (farm == null) {
                toast("Farm not found")
                finish()
                return@launchSafely
            }

            // Only the farm owner can delete at draw crop areas
            val canEdit = accessPolicy.canEdit(farm)
            binding.btnDeleteFarm.visibility = if (canEdit) View.VISIBLE else View.GONE
            binding.btnDrawCropAreas.visibility = if (canEdit) View.VISIBLE else View.GONE

            // Display farm information
            binding.tvFarmName.text = farm.farmName
            binding.tvFarmId.text = "Farm ID: ${farm.farmCode}" +
                    if (canEdit) "" else "  •  View only"
            binding.tvOwner.text = farm.ownerName
            binding.tvContact.text = farm.contactNumber
            binding.tvAddress.text = farm.farmAddress

            val latitude = farm.latitude
            val longitude = farm.longitude

            if (
                latitude.isFinite() &&
                longitude.isFinite() &&
                latitude in -90.0..90.0 &&
                longitude in -180.0..180.0 &&
                (latitude != 0.0 || longitude != 0.0)
            ) {
                binding.tvLatitude.text = "Latitude: $latitude"
                binding.tvLongitude.text = "Longitude: $longitude"

                // Display satellite map
                displayFarmMap(latitude, longitude, farm.farmName)

            } else {
                binding.tvLatitude.text = "Latitude: Not available"
                binding.tvLongitude.text = "Longitude: Not available"

                toast("Invalid or missing farm coordinates")
            }
        }
    }

    // Display the crop area with crop name
    private fun loadCropBoundaries() {
        if (!hasValidFarm()) return

        launchSafely("Unable to load crop areas") {
            val boundaries = boundaryRepository.getForFarm(farmId)

            farmMap.overlays.removeAll(boundaryOverlays)
            boundaryOverlays.clear()

            val colors = listOf(
                Color.rgb(255, 87, 34),
                Color.rgb(33, 150, 243),
                Color.rgb(255, 235, 59),
                Color.rgb(156, 39, 176),
                Color.rgb(0, 200, 83)
            )

            boundaries.forEachIndexed { index, boundary ->

                if (boundary.points.size < 3) return@forEachIndexed

                val color = colors[index % colors.size]

                val geoPoints = boundary.points.map {
                    GeoPoint(it.first, it.second)
                }

                // Outline
                val CropShape= Polygon(farmMap)
                CropShape.points = geoPoints
                CropShape.fillPaint.color = Color.argb(
                    90,
                    Color.red(color),
                    Color.green(color),
                    Color.blue(color)
                )
                CropShape.outlinePaint.color = color
                CropShape.outlinePaint.strokeWidth = 5f
                CropShape.title = boundary.cropName

                // CROP NAME IN CROP AREA MAP
                val label = Marker(farmMap)
                label.position = GeoPoint(
                    boundary.points.map { it.first }.average(),
                    boundary.points.map { it.second }.average()
                )
                label.setTextIcon(boundary.cropName)
                label.setAnchor(
                    Marker.ANCHOR_CENTER,
                    Marker.ANCHOR_CENTER
                )

                boundaryOverlays.add(CropShape)
                boundaryOverlays.add(label)
            }


            farmMap.overlays.addAll(0, boundaryOverlays)
            farmMap.invalidate()
        }
    }

    private fun confirmDeleteFarm() {
        AlertDialog.Builder(this)
            .setTitle("Delete Farm")
            .setMessage("Move to Recycle Bin?")
            .setPositiveButton("Delete") { _, _ ->
                launchSafely("Delete failed") {

                    if (!canEditThisFarm()) {
                        toast("View only: You can't edit")
                        return@launchSafely
                    }

                    farmRepository.moveToTrash(farmId)

                    toast("Farm moved to Recycle Bin")
                    finish()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Display satellite imagery and farm marker
    private fun displayFarmMap(
        latitude: Double,
        longitude: Double,
        farmName: String
    ) {
        val satelliteSource = object : XYTileSource(
            "EsriSatellite",
            0,
            19,
            256,
            ".jpg",
            arrayOf("https://services.arcgisonline.com/")
        ) {

            override fun getTileURLString(tileIndex: Long): String {
                val zoom = MapTileIndex.getZoom(tileIndex)
                val x = MapTileIndex.getX(tileIndex)
                val y = MapTileIndex.getY(tileIndex)

                return "https://services.arcgisonline.com/" +
                        "ArcGIS/rest/services/World_Imagery/" +
                        "MapServer/tile/$zoom/$y/$x"
            }
        }

        // Set satellite map
        farmMap.setTileSource(satelliteSource)

        // Farm coordinates
        val farmLocation = GeoPoint(latitude, longitude)

        // Center map on the farm
        farmMap.controller.setZoom(17.0)
        farmMap.controller.setCenter(farmLocation)

        // Create marker
        val marker = Marker(farmMap)

        marker.position = farmLocation
        marker.title = farmName
        marker.snippet = "Latitude: $latitude\nLongitude: $longitude"

        marker.setAnchor(
            Marker.ANCHOR_CENTER,
            Marker.ANCHOR_BOTTOM
        )

        // Add marker to map
        farmMap.overlays.add(marker)
        marker.showInfoWindow()
        farmMap.invalidate()
    }

    // Map lifecycle
    override fun onResume() {
        super.onResume()

        if (::farmMap.isInitialized) {
            farmMap.onResume()
            loadCropBoundaries()
        }
    }

    override fun onPause() {
        if (::farmMap.isInitialized) {
            farmMap.onPause()
        }

        super.onPause()
    }

    override fun onDestroy() {
        if (::farmMap.isInitialized) {
            farmMap.onDetach()
        }

        super.onDestroy()
    }
}
