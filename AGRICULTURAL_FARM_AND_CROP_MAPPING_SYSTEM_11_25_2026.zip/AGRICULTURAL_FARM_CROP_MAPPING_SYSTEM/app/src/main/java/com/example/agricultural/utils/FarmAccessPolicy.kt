package com.example.agricultural.utils
import com.example.agricultural.model.*
enum class FarmRole { OWNER, VIEWER }

class FarmAccessPolicy(private val currentUserId: Int) {

    fun roleFor(farm: Farm): FarmRole =
        if (farm.isOwnedBy(currentUserId)) FarmRole.OWNER else FarmRole.VIEWER

    fun canEdit(farm: Farm): Boolean = roleFor(farm) == FarmRole.OWNER
}
