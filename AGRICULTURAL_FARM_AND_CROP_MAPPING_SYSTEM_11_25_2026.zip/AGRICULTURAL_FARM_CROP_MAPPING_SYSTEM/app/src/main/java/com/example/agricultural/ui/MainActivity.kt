package com.example.agricultural.ui
import android.content.Intent
import android.os.Bundle
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.agricultural.databinding.ActivityMainBinding
import com.example.agricultural.repository.*
import com.example.agricultural.adapter.*
import com.example.agricultural.database.*
import com.example.agricultural.R
// Home Dashboard.
class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding

    private val farmRepository: FarmRepository by lazy { database.farmDao() }

    private val adapter = FarmAdapter { farm ->
        val intent = Intent(this, FarmDetailsActivity::class.java)
        intent.putExtra(FarmScopedActivity.EXTRA_FARM_ID, farm.id)
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupButtons()
        setupSearch()
        setupBottomNavigation()

        insertAgriculturalFarms()
    }

    private fun setupRecyclerView() {
        binding.rvFarms.layoutManager = LinearLayoutManager(this)
        binding.rvFarms.adapter = adapter
    }

    private fun setupButtons() {
        binding.btnAddFarm.setOnClickListener {
            startActivity(Intent(this, AddFarmActivity::class.java))
        }
    }

    private fun setupSearch() {
        binding.etSearch.doAfterTextChanged { text ->
            loadFarms(text?.toString()?.trim().orEmpty())
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_home -> {
                    loadFarms("")
                    true
                }

                R.id.nav_map -> {
                    startActivity(Intent(this, FarmMapActivity::class.java))
                    true
                }

                R.id.nav_reports -> {
                    startActivity(Intent(this, ReportsActivity::class.java))
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }

    private fun insertAgriculturalFarms() {
        launchSafely("Database error") {
            val seeder = SampleDataSeeder(
                farmRepository = farmRepository,
                cropRepository = database.cropDao(),
                harvestRepository = database.harvestDao(),
                areaRepository = database.productionAreaDao()
            )

            val addedCount = seeder.seed()

            loadFarms("")

            if (addedCount > 0) {
                toast("$addedCount new farm records added!", long = true)
            }
        }
    }

    private fun loadFarms(query: String) {
        launchSafely("Search error") {
            val farms = if (query.isBlank()) {
                farmRepository.getAll()
            } else {
                farmRepository.search(query)
            }

            adapter.submitList(farms)
            binding.tvFarmCount.text = "${farms.size} Farms"
        }
    }

    override fun onResume() {
        super.onResume()

        if (::binding.isInitialized) {
            loadFarms(
                binding.etSearch.text
                    ?.toString()
                    ?.trim()
                    .orEmpty()
            )
        }
    }
}
