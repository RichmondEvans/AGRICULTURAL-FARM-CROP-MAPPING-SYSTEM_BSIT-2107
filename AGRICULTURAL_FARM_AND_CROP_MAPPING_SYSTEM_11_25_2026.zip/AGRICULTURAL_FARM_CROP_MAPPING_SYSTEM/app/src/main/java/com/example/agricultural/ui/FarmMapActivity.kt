package com.example.agricultural.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged
import com.example.agricultural.R
import com.example.agricultural.model.*
import com.example.agricultural.repository.*
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File

// FARM MAP SCREEN
class FarmMapActivity : BaseActivity() {

    private lateinit var mapView: MapView
    private lateinit var spBarangay: Spinner
    private lateinit var etMapSearch: EditText

    private val farmRepository: FarmRepository by lazy { database.farmDao() }

    // Center point of Nasugbu
    private val nasugbuCenter = GeoPoint(14.0667, 120.6333)

    // List of barangays in Nasugbu
    private val barangayNames = listOf(
        "Aga", "Balaytigui", "Banilad",
        "Barangay 1", "Barangay 2", "Barangay 3", "Barangay 4",
        "Barangay 5", "Barangay 6", "Barangay 7", "Barangay 8",
        "Barangay 9", "Barangay 10", "Barangay 11", "Barangay 12",
        "Bilaran", "Bucana", "Bulihan", "Bunducan", "Butucan",
        "Calayo", "Catandaan", "Cogunan", "Dayap", "Kaylaway",
        "Kayrilaw", "Latag", "Looc", "Lumbangan", "Malapad na Bato",
        "Maugat", "Munting Indan", "Natipuan", "Pantalan", "Papaya",
        "Putat", "Reparo", "Talangan", "Tumalim", "Utod", "Wawa"
    )

    private val allBarangays = "All Barangays"
    private var selectedBarangay = allBarangays
    private var selectedFarmId = 0
    private var allFarms: List<Farm> = emptyList()
    private var availableBarangays: List<String> = emptyList()

    // Photo picker to edit farm photo
    private val editFarmPhotoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult

            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )

                launchSafely("Unable to update photo") {
                    val farm = farmRepository.getById(selectedFarmId)

                    // Only the farm owner can change the photo
                    if (farm == null || !accessPolicy.canEdit(farm)) {
                        toast("View only: You can't edit")
                        return@launchSafely
                    }

                    val result = farmRepository.updateFarmPhoto(selectedFarmId, uri.toString())

                    if (result > 0) {
                        toast("Farm photo updated!")
                        loadFarmMarkers()
                    } else {
                        toast("Farm not found")
                    }
                }
            } catch (_: Exception) {
                toast("Unable to access photo")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupOsmConfiguration()
        setContentView(R.layout.activity_farm_map)

        mapView = findViewById(R.id.mapView)
        spBarangay = findViewById(R.id.spBarangay)
        etMapSearch = findViewById(R.id.etMapSearch)

        setupMap()

        etMapSearch.doAfterTextChanged { displayFilteredFarms() }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        loadFarmMarkers()
    }

    // ---------- MAP SETUP ----------

    private fun setupOsmConfiguration() {
        val osmFolder = File(filesDir, "osmdroid")
        val tileFolder = File(osmFolder, "tiles")
        tileFolder.mkdirs()

        val config = Configuration.getInstance()
        config.userAgentValue = "AgriFarm/1.0 (com.example.agricultural)"
        config.osmdroidBasePath = osmFolder
        config.osmdroidTileCache = tileFolder
    }

    private fun setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.setBuiltInZoomControls(true)
        mapView.setMinZoomLevel(11.0)
        mapView.setMaxZoomLevel(19.0)
        mapView.controller.setZoom(13.0)
        mapView.controller.setCenter(nasugbuCenter)
        mapView.overlays.add(CopyrightOverlay(this))
        mapView.invalidate()
    }

    // ---------- LOAD FARMS ----------

    private fun loadFarmMarkers() {
        launchSafely("Unable to load farms") {
            allFarms = farmRepository.getAll()

            // Only barangays that have registered farms
            availableBarangays = allFarms
                .filter { isNasugbu(it) }
                .mapNotNull { farm ->
                    barangayNames.firstOrNull { belongsToBarangay(farm.farmAddress, it) }
                }
                .distinct()
                .sorted()

            setupBarangaySpinner()

            selectedBarangay = allBarangays
            displayFilteredFarms()
        }
    }

    private fun setupBarangaySpinner() {
        val barangays = listOf(allBarangays) + availableBarangays

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, barangays)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spBarangay.adapter = adapter

        spBarangay.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, position: Int, id: Long
            ) {
                selectedBarangay = barangays[position]
                moveToBarangay(selectedBarangay)
                displayFilteredFarms()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    // ---------- ADDRESS HELPERS ----------

    private fun isNasugbu(farm: Farm): Boolean =
        farm.farmAddress.contains("Nasugbu", ignoreCase = true)

    private fun normalizeAddress(address: String): String {
        return address
            .lowercase()
            .replace(Regex("\\bbarangay\\b"), " ")
            .replace(Regex("\\bbrgy\\.?\\b"), " ")
            .replace(",", " ")
            .replace(".", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun belongsToBarangay(address: String, barangay: String): Boolean {
        val normalizedAddress = normalizeAddress(address)
        val normalizedBarangay = normalizeAddress(barangay)

        // One-word barangay must match a whole word, multi-word just needs to be inside
        return if (" " in normalizedBarangay) {
            normalizedAddress.contains(normalizedBarangay)
        } else {
            normalizedAddress.split(" ").contains(normalizedBarangay)
        }
    }

    // ---------- MAP ACTIONS ----------

    private fun moveToBarangay(barangay: String) {
        if (barangay == allBarangays) {
            mapView.controller.setZoom(12.0)
            mapView.controller.animateTo(nasugbuCenter)
            return
        }

        val farms = allFarms.filter {
            isNasugbu(it) && belongsToBarangay(it.farmAddress, barangay)
        }
        if (farms.isEmpty()) return

        // Center of all farms in the barangay
        val center = GeoPoint(
            farms.map { it.latitude }.average(),
            farms.map { it.longitude }.average()
        )

        mapView.controller.setZoom(15.5)
        mapView.controller.animateTo(center)
        mapView.invalidate()
    }

    private fun displayFilteredFarms() {
        // Remove old markers
        mapView.overlays.removeAll { it is Marker }

        val searchText = etMapSearch.text.toString().trim()

        val filteredFarms = allFarms.filter { farm ->
            val matchesBarangay = selectedBarangay == allBarangays ||
                    belongsToBarangay(farm.farmAddress, selectedBarangay)

            val matchesSearch = listOf(
                farm.farmName, farm.ownerName, farm.farmAddress, farm.farmCode
            ).any { it.contains(searchText, ignoreCase = true) }

            isNasugbu(farm) && matchesBarangay && matchesSearch
        }

        filteredFarms.forEach { mapView.overlays.add(createMarker(it)) }
        mapView.invalidate()

        toast("${filteredFarms.size} farm(s) found")
    }

    private fun createMarker(farm: Farm): Marker {
        return Marker(mapView).apply {
            position = GeoPoint(farm.latitude, farm.longitude)
            title = farm.farmName
            snippet = "Owner: ${farm.ownerName}\nAddress: ${farm.farmAddress}"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            setOnMarkerClickListener { _, _ ->
                showFarmDetails(farm)
                true
            }
        }
    }

    // ---------- FARM DETAILS BOTTOM SHEET ----------

    private fun showFarmDetails(farm: Farm) {
        val dialog = BottomSheetDialog(this)
        dialog.setContentView(R.layout.bottom_sheet_farm)

        showPhoto(dialog.findViewById(R.id.imgFarm), farm.farmPhoto)

        setText(dialog, R.id.txtFarmName, farm.farmName)
        setText(dialog, R.id.txtFarmCode, "Farm Code: ${farm.farmCode}")
        setText(dialog, R.id.txtOwner, "Owner: ${farm.ownerName}")
        setText(dialog, R.id.txtAddress, "Address: ${farm.farmAddress}")
        setText(dialog, R.id.txtCoordinates, "Coordinates: ${farm.latitude}, ${farm.longitude}")
        setText(
            dialog, R.id.txtContact,
            if (farm.contactNumber.isBlank()) "Contact: Not available"
            else "Contact: ${farm.contactNumber}"
        )

        // View Details button
        dialog.findViewById<Button>(R.id.btnViewDetails)?.setOnClickListener {
            val intent = Intent(this, FarmDetailsActivity::class.java)
            intent.putExtra(FarmScopedActivity.EXTRA_FARM_ID, farm.id)
            dialog.dismiss()
            startActivity(intent)
        }

        // Edit Photo button (farm owner only)
        val editPhotoButton = dialog.findViewById<Button>(R.id.btnEditPhoto)

        if (accessPolicy.canEdit(farm)) {
            editPhotoButton?.setOnClickListener {
                selectedFarmId = farm.id
                editFarmPhotoPicker.launch(arrayOf("image/*"))
            }
        } else {
            editPhotoButton?.visibility = View.GONE
        }

        // Directions button
        dialog.findViewById<Button>(R.id.btnDirections)?.setOnClickListener {
            val uri = Uri.parse(
                "https://www.openstreetmap.org/directions?to=${farm.latitude}%2C${farm.longitude}"
            )

            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                toast("Unable to open directions")
            }
        }

        dialog.show()
    }

    private fun setText(dialog: BottomSheetDialog, id: Int, text: String) {
        dialog.findViewById<TextView>(id)?.text = text
    }

    // Shows the farm photo, or the placeholder if there is none / it can't be loaded
    private fun showPhoto(imageView: ImageView?, photo: String) {
        if (photo.isBlank()) {
            imageView?.setImageResource(R.drawable.farm_placeholder)
            return
        }

        try {
            imageView?.setImageURI(Uri.parse(photo))

            if (imageView?.drawable == null) {
                imageView?.setImageResource(R.drawable.farm_placeholder)
            }
        } catch (_: Exception) {
            imageView?.setImageResource(R.drawable.farm_placeholder)
        }
    }

    // ---------- LIFECYCLE ----------

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapView.onDetach()
        super.onDestroy()
    }
}