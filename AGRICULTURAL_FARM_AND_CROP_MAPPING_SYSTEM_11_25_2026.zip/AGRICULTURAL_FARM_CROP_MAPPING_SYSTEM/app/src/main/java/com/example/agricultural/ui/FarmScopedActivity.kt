package com.example.agricultural.ui
abstract class FarmScopedActivity : BaseActivity() {

    protected var farmId: Int = -1
        private set

    protected fun resolveFarmId(): Boolean {
        farmId = intent.getIntExtra(EXTRA_FARM_ID, -1)

        if (farmId <= 0) {
            toast("Invalid Farm ID", long = true)
            finish()
            return false
        }

        return true
    }

    protected fun hasValidFarm(): Boolean = farmId > 0

    protected suspend fun canEditThisFarm(): Boolean {
        val farm = database.farmDao().getById(farmId) ?: return false
        return accessPolicy.canEdit(farm)
    }

    companion object {
        const val EXTRA_FARM_ID = "farm_id"
    }
}
