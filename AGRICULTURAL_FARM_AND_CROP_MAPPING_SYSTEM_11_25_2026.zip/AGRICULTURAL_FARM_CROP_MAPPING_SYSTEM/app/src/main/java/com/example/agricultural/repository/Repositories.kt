package com.example.agricultural.repository
import com.example.agricultural.model.*
interface ReadRepository<Record> {
    suspend fun getById(id: Int): Record?
    suspend fun getAll(): List<Record>
}

interface WriteRepository<Record> {
    suspend fun insert(item: Record): Long
    suspend fun update(item: Record): Int
    suspend fun delete(id: Int): Int
}

interface FarmScopedRepository<Record : AgriculturalRecord> :
    ReadRepository<Record>, WriteRepository<Record> {
    suspend fun getByFarmId(farmId: Int): List<Record>
}

interface CropRepository : FarmScopedRepository<Crop>

interface ProductionAreaRepository : FarmScopedRepository<ProductionArea>

interface HarvestRepository : FarmScopedRepository<Harvest>

interface BusinessRepository : FarmScopedRepository<FarmBusiness>

interface FarmRepository : ReadRepository<Farm>, WriteRepository<Farm> {
    suspend fun search(keyword: String): List<Farm>
    suspend fun count(): Int
    suspend fun updateFarmPhoto(farmId: Int, photoUri: String): Int

    // Recycle bin (soft delete)
    suspend fun getTrashFarms(): List<Farm>
    suspend fun moveToTrash(farmId: Int): Int
    suspend fun restoreFarm(farmId: Int): Int
}
interface BoundaryRepository {
    suspend fun save(cropId: Int, points: List<Pair<Double, Double>>)
    suspend fun get(cropId: Int): List<Pair<Double, Double>>
    suspend fun delete(cropId: Int): Int
    suspend fun getForFarm(farmId: Int): List<CropBoundary>
}
