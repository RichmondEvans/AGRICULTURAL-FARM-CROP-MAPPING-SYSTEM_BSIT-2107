package com.example.agricultural.model

abstract class AgriculturalRecord {
    abstract val id: Int
    abstract val farmId: Int
    abstract val displayTitle: String
}
