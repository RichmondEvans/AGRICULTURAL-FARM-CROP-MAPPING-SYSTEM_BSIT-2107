package com.example.agricultural.ui
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.viewbinding.ViewBinding
import com.example.agricultural.model.*
import com.example.agricultural.repository.*
import com.example.agricultural.utils.CardLine
import com.example.agricultural.utils.RecordCardBuilder

// BASE CLASS
abstract class RecordCrudActivity<Record : AgriculturalRecord, B : ViewBinding> :
    FarmScopedActivity() {

    protected lateinit var binding: B
        private set

    private var editingId = -1

    private var canEdit = false
    private var viewOnlyNotified = false

    private val cardBuilder by lazy {
        RecordCardBuilder(this)
    }

    protected abstract fun inflateBinding(inflater: LayoutInflater): B

    protected abstract val repository: FarmScopedRepository<Record>
    protected abstract val backButton: Button
    protected abstract val saveButton: Button
    protected abstract val listContainer: LinearLayout

    protected abstract val addLabel: String
    protected abstract val updateLabel: String
    protected abstract val editLabel: String
    protected abstract val deleteLabel: String
    protected abstract val emptyMessage: String
    protected abstract val savedMessage: String
    protected abstract val deletedMessage: String

    protected abstract fun readForm(recordId: Int): Record?
    protected abstract fun fillForm(record: Record)
    protected abstract fun clearForm()
    protected abstract fun cardLines(record: Record): List<CardLine>

    protected open fun cardTitle(record: Record): String = record.displayTitle
    protected open suspend fun validate(record: Record): String? = null
    protected open suspend fun loadRecords(): List<Record> = repository.getByFarmId(farmId)
    protected open fun onRecordsLoaded(records: List<Record>) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = inflateBinding(layoutInflater)
        setContentView(binding.root)

        if (!resolveFarmId()) return

        backButton.setOnClickListener { finish() }
        saveButton.setOnClickListener { save() }
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && hasValidFarm()) refresh()
    }

    private fun save() {
        // Check muna bago gumawa ng kahit ano
        if (!canEdit) {
            toast("View only: You can't edit")
            return
        }

        val record = readForm(if (editingId > 0) editingId else 0) ?: return

        launchSafely("Save failed") {
            val errorMessage = validate(record)
            if (errorMessage != null) {
                toast(errorMessage)
                return@launchSafely
            }

            if (editingId > 0) {
                repository.update(record)
            } else {
                repository.insert(record)
            }

            resetForm()
            refresh()
            toast(savedMessage)
        }
    }

    private fun delete(record: Record) {
        if (!canEdit) {
            toast("View only: You can't edit")
            return
        }

        launchSafely("Delete failed") {
            repository.delete(record.id)
            if (editingId == record.id) resetForm()
            refresh()
            toast(deletedMessage)
        }
    }

    private fun startEditing(record: Record) {
        editingId = record.id
        fillForm(record)
        saveButton.text = updateLabel
    }

    private fun resetForm() {
        editingId = -1
        clearForm()
        saveButton.text = addLabel
    }

    private fun applyAccessMode() {
        saveButton.visibility = if (canEdit) View.VISIBLE else View.GONE
        setInputsEnabled(binding.root, canEdit)

        if (!canEdit && !viewOnlyNotified) {
            viewOnlyNotified = true
            toast("View only: You can't edit", long = true)
        }
    }

    private fun setInputsEnabled(view: View, enabled: Boolean) {
        if (view is EditText || view is Spinner || view is CheckBox) {
            view.isEnabled = enabled
        }

        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                setInputsEnabled(view.getChildAt(i), enabled)
            }
        }
    }

    // Loads all records from the database and displays them as cards on the screen.
    private fun refresh() {
        launchSafely("Loading failed") {
            canEdit = canEditThisFarm()
            applyAccessMode()

            val records = loadRecords()
            listContainer.removeAllViews()

            if (records.isEmpty()) {
                listContainer.addView(emptyView())
            }

            records.forEach { record ->
                val cardView = cardBuilder.build(
                    title = cardTitle(record),
                    lines = cardLines(record),
                    editLabel = editLabel,
                    deleteLabel = deleteLabel,
                    onEdit = { startEditing(record) },
                    onDelete = { delete(record) },
                    canEdit = canEdit
                )
                listContainer.addView(cardView)
            }

            onRecordsLoaded(records)
        }
    }

    private fun emptyView() = TextView(this).apply {
        text = emptyMessage
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Color.GRAY)
        setPadding(20, 35, 20, 35)
    }
}
