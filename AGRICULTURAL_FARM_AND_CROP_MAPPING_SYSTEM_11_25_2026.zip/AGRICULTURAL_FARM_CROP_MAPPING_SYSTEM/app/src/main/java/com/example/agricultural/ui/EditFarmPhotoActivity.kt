package com.example.agricultural.ui
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import androidx.activity.result.contract.ActivityResultContracts
import com.example.agricultural.model.*
import com.example.agricultural.repository.*
import com.example.agricultural.R
class EditFarmPhotoActivity : BaseActivity() {

    private lateinit var spFarm: Spinner
    private lateinit var imgFarm: ImageView
    private lateinit var btnChoose: Button
    private lateinit var btnSave: Button

    private val farmRepository: FarmRepository by lazy { database.farmDao() }

    private var farms: List<Farm> = emptyList()
    private var selectedFarm: Farm? = null
    private var selectedPhoto: Uri? = null

    private val picker =
        registerForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )

                    selectedPhoto = uri
                    imgFarm.setImageURI(uri)

                } catch (_: Exception) {
                    toast("Unable to access photo")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_edit_farm_photo)

        spFarm = findViewById(R.id.spFarm)
        imgFarm = findViewById(R.id.imgFarm)
        btnChoose = findViewById(R.id.btnChoosePhoto)
        btnSave = findViewById(R.id.btnSavePhoto)

        loadFarms()

        btnChoose.setOnClickListener {
            picker.launch(arrayOf("image/*"))
        }

        btnSave.setOnClickListener {
            savePhoto()
        }
    }

    private fun loadFarms() {
        launchSafely("Unable to load farms") {
            // Sariling farm lang ang pwedeng palitan ng larawan
            farms = farmRepository.getAll().filter { accessPolicy.canEdit(it) }

            if (farms.isEmpty()) {
                toast("No farms found")
                return@launchSafely
            }

            val adapter = ArrayAdapter(
                this@EditFarmPhotoActivity,
                android.R.layout.simple_spinner_item,
                farms.map { it.farmName }
            )

            adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )

            spFarm.adapter = adapter

            spFarm.onItemSelectedListener =
                object : AdapterView.OnItemSelectedListener {

                    override fun onItemSelected(
                        parent: AdapterView<*>?,
                        view: View?,
                        position: Int,
                        id: Long
                    ) {
                        selectedFarm = farms[position]
                        selectedPhoto = null

                        val photo = farms[position].farmPhoto

                        if (photo.isNotBlank()) {
                            imgFarm.setImageURI(Uri.parse(photo))
                        } else {
                            imgFarm.setImageResource(R.drawable.farm_placeholder)
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
        }
    }

    private fun savePhoto() {
        val farm = selectedFarm
        val photo = selectedPhoto

        if (farm == null || photo == null) {
            toast("Select a farm and a photo first")
            return
        }

        if (!accessPolicy.canEdit(farm)) {
            toast("View only: You can't edit")
            return
        }

        launchSafely("Unable to update photo") {
            farmRepository.updateFarmPhoto(farm.id, photo.toString())

            toast("Farm photo updated successfully!")
            finish()
        }
    }
}
