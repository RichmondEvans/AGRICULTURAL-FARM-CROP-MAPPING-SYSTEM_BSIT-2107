package com.example.agricultural

import com.example.agricultural.model.*
import com.example.agricultural.ui.*
import com.example.agricultural.dao.*
import com.example.agricultural.repository.*
import com.example.agricultural.adapter.*
import com.example.agricultural.database.*
import com.example.agricultural.utils.*

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FarmAccessPolicyTest {

    private val farm = Farm(
        id = 1, farmName = "A", ownerName = "x", farmAddress = "y",
        contactNumber = "1", latitude = 0.0, longitude = 0.0,
        ownerUserId = 5
    )

    @Test
    fun owner_can_edit() {
        assertTrue(FarmAccessPolicy(5).canEdit(farm))
    }

    @Test
    fun other_user_is_only_a_viewer() {
        val policy = FarmAccessPolicy(6)
        assertFalse(policy.canEdit(farm))
        assertEquals(FarmRole.VIEWER, policy.roleFor(farm))
    }

    @Test
    fun farm_without_owner_is_view_only_for_everyone() {
        assertFalse(FarmAccessPolicy(0).canEdit(farm.copy(ownerUserId = 0)))
    }
}
