# AgriFarm: OOP & SOLID notes

## Structure

```
Models (inheritance)
  AgriculturalRecord (abstract: id, farmId, displayTitle)
    ├─ Farm  ├─ Crop  ├─ Harvest  ├─ ProductionArea  └─ FarmBusiness

Data layer
  Repositories.kt          small interfaces (ReadRepository, WriteRepository,
                           FarmScopedRepository<T>, FarmRepository, ...)
  BaseDao<T>               abstract: insert/update/delete/getById/getAll once
    ├─ FarmDao             (farms + recycle bin only)
    └─ FarmScopedDao<T>    abstract: adds getByFarmId
         ├─ CropDao  ├─ ProductionAreaDao  ├─ HarvestDao  └─ FarmBusinessDao
  BoundaryDao, FavoriteDao, FarmPhotoDao, UserDao   (one job each)
  AppDatabase              creates tables, returns INTERFACES

Services (single job each)
  ReportService            builds the Agricultural Report
  SampleDataSeeder         inserts the sample Nasugbu data
  FinancialSummary, Money  totals and peso formatting

Screens
  BaseActivity                       database, toast(), launchSafely()
    └─ FarmScopedActivity            reads/validates farm_id
         └─ RecordCrudActivity<T,B>  ONE save/edit/delete/list flow
              ├─ CropsActivity  ├─ ProductionAreaActivity
              └─ HarvestActivity └─ FarmBusinessActivity
  RecordCardBuilder                  builds the card with Edit/Delete
```

## Where each principle is used

| Principle | Where |
|---|---|
| Abstraction | `AgriculturalRecord`, `BaseDao`, `RecordCrudActivity` define WHAT is common; children define the details |
| Inheritance | models extend `AgriculturalRecord`; DAOs extend `BaseDao`/`FarmScopedDao`; screens extend `RecordCrudActivity` |
| Encapsulation | SQL is only inside DAOs; `farmId` has a private setter; `FarmDao.FARM_COLUMNS` is not repeated |
| Polymorphism | `RecordCrudActivity` works with any `T : AgriculturalRecord`; `cardLines()` differs per screen |
| S: Single Responsibility | `FarmDao` was 700 lines doing everything; now one DAO per table. Seeding moved out of `MainActivity`; math moved to `ReportService` / `FinancialSummary` |
| O: Open/Closed | A new record type = a new model + DAO + child of `RecordCrudActivity`. No change to the base classes |
| L: Liskov | Any `FarmScopedRepository<T>` (SQLite or a fake in tests) can replace another |
| I: Interface Segregation | `ReadRepository`, `WriteRepository`, `FavoriteRepository`, `BoundaryRepository`... instead of one giant interface |
| D: Dependency Inversion | Screens and services depend on interfaces; `AppDatabase.cropDao()` returns `CropRepository`. See `ReportServiceTest` (uses fakes, no database) |

## What was fixed

* The project did not compile: `Crop`, `Harvest`, `ProductionArea`, `FarmBusiness` already used `id`, but the DAOs and screens still used `cropId`, `areaId`, `harvestId`, `businessId`.
* `Harvest` now has `farmId` (read through a JOIN with `crops`).
* `crop_boundaries` table is created in `AppDatabase` (DB version 9) instead of on every call.
* Typo `DEFAULt` in the farms table SQL.
* Reports screen now shows farms, crops, areas, harvest, sales, expenses and profit, plus a summary per farm.
