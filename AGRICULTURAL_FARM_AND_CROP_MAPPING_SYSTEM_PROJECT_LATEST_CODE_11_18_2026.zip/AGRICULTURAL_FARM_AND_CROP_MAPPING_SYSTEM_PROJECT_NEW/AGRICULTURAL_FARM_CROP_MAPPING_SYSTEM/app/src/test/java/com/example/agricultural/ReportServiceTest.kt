package com.example.agricultural

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Shows Dependency Inversion: ReportService is tested with in-memory
 * fake repositories, no database or Android needed.
 */
class ReportServiceTest {

    /** One fake for every FarmScopedRepository (Liskov: it can replace any of them). */
    private class FakeRepo<T : AgriculturalRecord>(
        private val items: List<T>
    ) : FarmScopedRepository<T> {
        override suspend fun getByFarmId(farmId: Int) = items.filter { it.farmId == farmId }
        override suspend fun getById(id: Int) = items.firstOrNull { it.id == id }
        override suspend fun getAll() = items
        override suspend fun insert(item: T) = 0L
        override suspend fun update(item: T) = 0
        override suspend fun delete(id: Int) = 0
    }

    private class FakeFarms(private val farms: List<Farm>) : FarmRepository {
        override suspend fun getById(id: Int) = farms.firstOrNull { it.id == id }
        override suspend fun getAll() = farms
        override suspend fun insert(item: Farm) = 0L
        override suspend fun update(item: Farm) = 0
        override suspend fun delete(id: Int) = 0
        override suspend fun search(keyword: String) = farms
        override suspend fun count() = farms.size
        override suspend fun updateFarmPhoto(farmId: Int, photoUri: String) = 0
        override suspend fun getTrashFarms() = emptyList<Farm>()
        override suspend fun moveToTrash(farmId: Int) = 0
        override suspend fun restoreFarm(farmId: Int) = 0
    }

    private class FakeCrops(items: List<Crop>) :
        CropRepository, FarmScopedRepository<Crop> by FakeRepo(items)

    private class FakeAreas(items: List<ProductionArea>) :
        ProductionAreaRepository, FarmScopedRepository<ProductionArea> by FakeRepo(items)

    private class FakeHarvests(items: List<Harvest>) :
        HarvestRepository, FarmScopedRepository<Harvest> by FakeRepo(items)

    private class FakeBusiness(items: List<FarmBusiness>) :
        BusinessRepository, FarmScopedRepository<FarmBusiness> by FakeRepo(items)

    @Test
    fun report_totals_all_farms() = runBlocking {
        val farm1 = Farm(id = 1, farmName = "A", ownerName = "x", farmAddress = "y",
            contactNumber = "1", latitude = 0.0, longitude = 0.0)
        val farm2 = farm1.copy(id = 2, farmName = "B")

        val service = ReportService(
            farms = FakeFarms(listOf(farm1, farm2)),
            crops = FakeCrops(listOf(Crop(1, 1, "Mango", "Carabao", "Growing"))),
            areas = FakeAreas(listOf(ProductionArea(1, 2, "2 Ha", "Loam", "Active"))),
            harvests = FakeHarvests(listOf(Harvest(1, 1, 1, "2026-11-01", "A", 40.0))),
            business = FakeBusiness(
                listOf(FarmBusiness(1, 1, "Mango", quantitySold = 10.0, price = 50.0, expenses = 200.0))
            )
        )

        val report = service.generate()

        assertEquals(2, report.farmCount)
        assertEquals(1, report.cropCount)
        assertEquals(1, report.areaCount)
        assertEquals(40.0, report.totalHarvestQuantity, 0.0)
        assertEquals(500.0, report.finance.totalSales, 0.0)
        assertEquals(300.0, report.finance.profit, 0.0)
    }

    @Test
    fun farm_business_profit_is_sales_minus_expenses() {
        val record = FarmBusiness(1, 1, "Corn", quantitySold = 4.0, price = 25.0, expenses = 130.0)
        assertEquals(100.0, record.totalSales, 0.0)
        assertEquals(-30.0, record.profit, 0.0)
    }
}
