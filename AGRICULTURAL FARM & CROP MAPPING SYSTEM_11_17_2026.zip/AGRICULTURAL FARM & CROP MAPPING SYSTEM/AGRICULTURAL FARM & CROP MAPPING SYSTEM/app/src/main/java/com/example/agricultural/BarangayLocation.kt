
package com.example.agricultural

data class BarangayLocation(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val zoom: Double = 15.0
)
