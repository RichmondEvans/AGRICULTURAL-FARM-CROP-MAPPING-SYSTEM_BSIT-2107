package com.example.agricultural

import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.agricultural.databinding.ActivityHarvestBinding
import kotlinx.coroutines.launch

class HarvestActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHarvestBinding

    private val dao by lazy {
        AppDatabase.get(this).farmDao()
    }

    private var farmId = -1

    // -1 = nagdaragdag ng bago, higit sa 0 = nag-eedit ng record
    private var editingHarvestId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHarvestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        farmId = intent.getIntExtra("farm_id", -1)

        if (farmId <= 0) {
            Toast.makeText(this, "Invalid Farm ID", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSaveHarvest.setOnClickListener { saveHarvest() }

        loadHarvests()
    }

    private fun saveHarvest() {

        val cropId = binding.etCropId.text.toString().trim().toIntOrNull()
        val date = binding.etHarvestDate.text.toString().trim()
        val quality = binding.etHarvestQuality.text.toString().trim()
        val quantity = binding.etAvailableQuantity.text.toString().trim().toDoubleOrNull()

        if (
            cropId == null ||
            date.isBlank() ||
            quality.isBlank() ||
            quantity == null ||
            quantity < 0
        ) {
            Toast.makeText(
                this,
                "Please enter valid information",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        lifecycleScope.launch {
            try {

                val crops = dao.getCrops(farmId)

                if (crops.none { it.cropId == cropId }) {
                    Toast.makeText(
                        this@HarvestActivity,
                        "Crop ID does not belong to this farm",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@launch
                }

                if (editingHarvestId > 0) {
                    dao.updateHarvest(
                        Harvest(
                            harvestId = editingHarvestId,
                            cropId = cropId,
                            harvestDate = date,
                            harvestQuality = quality,
                            availableQuantity = quantity
                        )
                    )
                    editingHarvestId = -1
                    binding.btnSaveHarvest.text = "＋ Save Harvest"
                } else {
                    dao.insertHarvest(
                        Harvest(
                            cropId = cropId,
                            harvestDate = date,
                            harvestQuality = quality,
                            availableQuantity = quantity
                        )
                    )
                }

                binding.etCropId.text.clear()
                binding.etHarvestDate.text.clear()
                binding.etHarvestQuality.text.clear()
                binding.etAvailableQuantity.text.clear()

                loadHarvests()

                Toast.makeText(
                    this@HarvestActivity,
                    "Harvest saved successfully!",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (e: Exception) {
                Toast.makeText(
                    this@HarvestActivity,
                    "Save failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun loadHarvests() {

        lifecycleScope.launch {
            try {

                val harvests = dao.getHarvests(farmId)

                binding.layoutHarvestList.removeAllViews()

                if (harvests.isEmpty()) {
                    val empty = TextView(this@HarvestActivity)
                    empty.text = "No harvest records available."
                    empty.textSize = 15f
                    empty.gravity = Gravity.CENTER
                    empty.setTextColor(Color.GRAY)
                    empty.setPadding(20, 35, 20, 35)
                    binding.layoutHarvestList.addView(empty)
                }

                harvests.forEach { harvest ->

                    val card = LinearLayout(this@HarvestActivity)
                    card.orientation = LinearLayout.VERTICAL
                    card.setPadding(20, 18, 20, 18)
                    card.setBackgroundColor(Color.rgb(240, 248, 240))

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 8, 0, 12)
                    card.layoutParams = params

                    val title = TextView(this@HarvestActivity)
                    title.text = "Harvest Record"
                    title.textSize = 19f
                    title.setTypeface(null, Typeface.BOLD)
                    title.setTextColor(Color.rgb(35, 100, 55))
                    card.addView(title)

                    val crop = TextView(this@HarvestActivity)
                    crop.text = "Crop ID: ${harvest.cropId}"
                    crop.textSize = 15f
                    crop.setTextColor(Color.DKGRAY)
                    crop.setPadding(0, 8, 0, 0)
                    card.addView(crop)

                    val date = TextView(this@HarvestActivity)
                    date.text = "Harvest Date: ${harvest.harvestDate}"
                    date.textSize = 15f
                    date.setTextColor(Color.DKGRAY)
                    date.setPadding(0, 5, 0, 0)
                    card.addView(date)

                    val quality = TextView(this@HarvestActivity)
                    quality.text = "Quality: ${harvest.harvestQuality}"
                    quality.textSize = 15f
                    quality.setTextColor(Color.DKGRAY)
                    quality.setPadding(0, 5, 0, 0)
                    card.addView(quality)

                    val quantity = TextView(this@HarvestActivity)
                    quantity.text = "Available Quantity: ${harvest.availableQuantity}"
                    quantity.textSize = 15f
                    quantity.setTypeface(null, Typeface.BOLD)
                    quantity.setTextColor(Color.rgb(35, 100, 55))
                    quantity.setPadding(0, 5, 0, 12)
                    card.addView(quantity)

                    // EDIT BUTTON
                    val edit = Button(this@HarvestActivity)
                    edit.text = "Edit Harvest"
                    edit.setOnClickListener {
                        editingHarvestId = harvest.harvestId
                        binding.etCropId.setText(harvest.cropId.toString())
                        binding.etHarvestDate.setText(harvest.harvestDate)
                        binding.etHarvestQuality.setText(harvest.harvestQuality)
                        binding.etAvailableQuantity.setText(
                            harvest.availableQuantity.toString()
                        )
                        binding.btnSaveHarvest.text = "Update Harvest"
                    }
                    card.addView(edit)

                    // DELETE BUTTON
                    val delete = Button(this@HarvestActivity)
                    delete.text = "Delete Harvest"

                    delete.setOnClickListener {
                        lifecycleScope.launch {
                            try {
                                dao.deleteHarvest(harvest.harvestId)
                                loadHarvests()

                                Toast.makeText(
                                    this@HarvestActivity,
                                    "Harvest deleted",
                                    Toast.LENGTH_SHORT
                                ).show()

                            } catch (e: Exception) {
                                Toast.makeText(
                                    this@HarvestActivity,
                                    "Delete failed: ${e.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }

                    card.addView(delete)
                    binding.layoutHarvestList.addView(card)
                }

            } catch (e: Exception) {
                Toast.makeText(
                    this@HarvestActivity,
                    "Loading failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && farmId > 0) {
            loadHarvests()
        }
    }
}