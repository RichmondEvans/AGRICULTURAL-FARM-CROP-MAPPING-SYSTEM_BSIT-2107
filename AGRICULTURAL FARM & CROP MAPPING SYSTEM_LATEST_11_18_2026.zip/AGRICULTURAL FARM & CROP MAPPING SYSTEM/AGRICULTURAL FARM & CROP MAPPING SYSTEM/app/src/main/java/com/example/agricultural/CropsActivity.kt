
package com.example.agricultural

import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.agricultural.databinding.ActivityCropsBinding
import kotlinx.coroutines.launch

class CropsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCropsBinding

    private val dao by lazy {
        AppDatabase.get(this).farmDao()
    }

    private var farmId = -1

    private var editingCropId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCropsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        farmId = intent.getIntExtra("farm_id", -1)

        if (farmId <= 0) {
            Toast.makeText(this, "Invalid Farm ID", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSaveCrop.setOnClickListener { saveCrop() }

        loadCrops()
    }

    private fun saveCrop() {
        val name = binding.etCropName.text.toString().trim()
        val variety = binding.etCropVariety.text.toString().trim()
        val status = binding.etCropStatus.text.toString().trim()

        if (name.isBlank() || variety.isBlank() || status.isBlank()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                if (editingCropId > 0) {
                    dao.updateCrop(
                        Crop(
                            cropId = editingCropId,
                            farmId = farmId,
                            cropName = name,
                            cropVariety = variety,
                            cropStatus = status
                        )
                    )
                    editingCropId = -1
                    binding.btnSaveCrop.text = "＋ Save Crop"
                } else {
                    dao.insertCrop(
                        Crop(
                            farmId = farmId,
                            cropName = name,
                            cropVariety = variety,
                            cropStatus = status
                        )
                    )
                }

                binding.etCropName.text.clear()
                binding.etCropVariety.text.clear()
                binding.etCropStatus.text.clear()

                loadCrops()

                Toast.makeText(
                    this@CropsActivity,
                    "Crop saved successfully!",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (e: Exception) {
                Toast.makeText(
                    this@CropsActivity,
                    "Save failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun loadCrops() {
        lifecycleScope.launch {
            try {
                val crops = dao.getCrops(farmId)
                binding.layoutCropList.removeAllViews()

                if (crops.isEmpty()) {
                    val empty = TextView(this@CropsActivity)
                    empty.text = "No crops registered yet."
                    empty.textSize = 15f
                    empty.gravity = Gravity.CENTER
                    empty.setTextColor(Color.GRAY)
                    empty.setPadding(20, 35, 20, 35)
                    binding.layoutCropList.addView(empty)
                }

                crops.forEach { crop ->
                    val card = LinearLayout(this@CropsActivity)
                    card.orientation = LinearLayout.VERTICAL
                    card.setPadding(20, 18, 20, 18)
                    card.setBackgroundColor(Color.rgb(240, 248, 240))

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 8, 0, 12)
                    card.layoutParams = params

                    val title = TextView(this@CropsActivity)
                    title.text = crop.cropName
                    title.textSize = 19f
                    title.setTypeface(null, Typeface.BOLD)
                    title.setTextColor(Color.rgb(35, 100, 55))
                    card.addView(title)

                    val variety = TextView(this@CropsActivity)
                    variety.text = "Variety: ${crop.cropVariety}"
                    variety.textSize = 15f
                    variety.setTextColor(Color.DKGRAY)
                    variety.setPadding(0, 8, 0, 0)
                    card.addView(variety)

                    val status = TextView(this@CropsActivity)
                    status.text = "Status: ${crop.cropStatus}"
                    status.textSize = 15f
                    status.setTextColor(Color.DKGRAY)
                    status.setPadding(0, 5, 0, 12)
                    card.addView(status)

                    val delete = Button(this@CropsActivity)
                    delete.text = "Delete Crop"
                    delete.setOnClickListener {
                        lifecycleScope.launch {
                            try {
                                dao.deleteCrop(crop.cropId)
                                loadCrops()
                                Toast.makeText(
                                    this@CropsActivity,
                                    "Crop deleted",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } catch (e: Exception) {
                                Toast.makeText(
                                    this@CropsActivity,
                                    "Delete failed: ${e.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                    val edit = Button(this@CropsActivity)
                    edit.text = "Edit Crop"
                    edit.setOnClickListener {
                        editingCropId = crop.cropId
                        binding.etCropName.setText(crop.cropName)
                        binding.etCropVariety.setText(crop.cropVariety)
                        binding.etCropStatus.setText(crop.cropStatus)
                        binding.btnSaveCrop.text = "Update Crop"
                    }
                    card.addView(edit)

                    card.addView(delete)
                    binding.layoutCropList.addView(card)
                }

            } catch (e: Exception) {
                Toast.makeText(
                    this@CropsActivity,
                    "Loading failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && farmId > 0) {
            loadCrops()
        }
    }
}
