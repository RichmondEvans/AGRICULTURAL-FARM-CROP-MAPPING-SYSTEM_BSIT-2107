package com.example.agricultural

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FarmDao(private val db: AppDatabase) {

    private val columns = """
        id, farmName, ownerName, farmAddress,
        contactNumber, latitude, longitude, farmPhoto, website
    """.trimIndent().replace("\n", " ")

    // =====================================
    // FARMS
    // =====================================

    suspend fun insert(farm: Farm): Long =
        withContext(Dispatchers.IO) {
            db.writableDatabase.insertOrThrow(
                "farms",
                null,
                farmValues(farm)
            )
        }

    private fun farmValues(farm: Farm) =
        ContentValues().apply {
            put("farmName", farm.farmName)
            put("ownerName", farm.ownerName)
            put("farmAddress", farm.farmAddress)
            put("contactNumber", farm.contactNumber)
            put("latitude", farm.latitude)
            put("longitude", farm.longitude)
            put("farmPhoto", farm.farmPhoto)
            put("website", farm.website)
        }

    // Farms na HINDI nasa Recycle Bin
    suspend fun getAll(): List<Farm> =
        withContext(Dispatchers.IO) {
            read(
                "SELECT $columns FROM farms WHERE isDeleted = 0 ORDER BY id ASC",
                null
            )
        }

    // Lahat ng farm, kasama ang nasa Recycle Bin
    // (para sa sample data sa MainActivity)
    suspend fun getAllIncludingTrash(): List<Farm> =
        withContext(Dispatchers.IO) {
            read(
                "SELECT $columns FROM farms ORDER BY id ASC",
                null
            )
        }

    suspend fun search(q: String): List<Farm> =
        withContext(Dispatchers.IO) {

            val keyword = q.trim()

            if (keyword.isEmpty()) {
                return@withContext getAll()
            }

            val searchText = "%$keyword%"

            read(
                """
            SELECT $columns
            FROM farms
            WHERE isDeleted = 0
              AND (farmName LIKE ? COLLATE NOCASE
               OR ownerName LIKE ? COLLATE NOCASE
               OR farmAddress LIKE ? COLLATE NOCASE)
            ORDER BY farmName COLLATE NOCASE ASC
            """.trimIndent(),
                arrayOf(
                    searchText,
                    searchText,
                    searchText
                )
            )
        }

    suspend fun getById(id: Int): Farm? =
        withContext(Dispatchers.IO) {
            read(
                "SELECT $columns FROM farms WHERE id = ?",
                arrayOf(id.toString())
            ).firstOrNull()
        }

    suspend fun count(): Int =
        withContext(Dispatchers.IO) {
            db.readableDatabase.rawQuery(
                "SELECT COUNT(*) FROM farms WHERE isDeleted = 0",
                null
            ).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
        }

    suspend fun updateFarmPhoto(
        farmId: Int,
        photoUri: String
    ): Int = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put("farmPhoto", photoUri)
        }

        db.writableDatabase.update(
            "farms",
            values,
            "id = ?",
            arrayOf(farmId.toString())
        )
    }

    suspend fun updateFarm(farm: Farm): Int =
        withContext(Dispatchers.IO) {
            db.writableDatabase.update(
                "farms",
                farmValues(farm),
                "id = ?",
                arrayOf(farm.id.toString())
            )
        }

    // Tuluyang pagbura (kasama ang crops, harvests, business, atbp.)
    suspend fun deleteFarm(farmId: Int) =
        withContext(Dispatchers.IO) {
            db.writableDatabase.delete(
                "farms",
                "id = ?",
                arrayOf(farmId.toString())
            )
        }

    // =====================================
    // RECYCLE BIN
    // =====================================

    suspend fun getTrashFarms(): List<Farm> =
        withContext(Dispatchers.IO) {
            read(
                "SELECT $columns FROM farms WHERE isDeleted = 1 " +
                        "ORDER BY farmName COLLATE NOCASE ASC",
                null
            )
        }

    suspend fun moveToTrash(farmId: Int) = setDeleted(farmId, 1)

    suspend fun restoreFarm(farmId: Int) = setDeleted(farmId, 0)

    private suspend fun setDeleted(farmId: Int, value: Int) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("isDeleted", value)
            }

            db.writableDatabase.update(
                "farms",
                values,
                "id = ?",
                arrayOf(farmId.toString())
            )
        }

    // =====================================
    // FAVORITES
    // =====================================

    suspend fun saveFavorite(farmId: Int) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("farmId", farmId)
            }

            db.writableDatabase.insertWithOnConflict(
                "farm_favorites",
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
            )
        }

    suspend fun removeFavorite(farmId: Int) =
        withContext(Dispatchers.IO) {
            db.writableDatabase.delete(
                "farm_favorites",
                "farmId = ?",
                arrayOf(farmId.toString())
            )
        }

    suspend fun isFavorite(farmId: Int): Boolean =
        withContext(Dispatchers.IO) {
            db.readableDatabase.rawQuery(
                "SELECT 1 FROM farm_favorites WHERE farmId = ?",
                arrayOf(farmId.toString())
            ).use { it.moveToFirst() }
        }

    suspend fun getFavoriteFarmIds(): List<Int> =
        withContext(Dispatchers.IO) {
            val result = mutableListOf<Int>()

            db.readableDatabase.rawQuery(
                "SELECT farmId FROM farm_favorites ORDER BY farmId",
                null
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    result.add(cursor.getInt(0))
                }
            }

            result
        }

    suspend fun getFavoriteFarms(): List<Farm> =
        withContext(Dispatchers.IO) {
            read(
                """
                SELECT f.id, f.farmName, f.ownerName, f.farmAddress,
                f.contactNumber, f.latitude, f.longitude,
                f.farmPhoto, f.website
                FROM farms f
                INNER JOIN farm_favorites ff
                ON f.id = ff.farmId
                WHERE f.isDeleted = 0
                ORDER BY f.farmName
                """.trimIndent(),
                null
            )
        }

    // =====================================
    // FARM PHOTOS
    // =====================================

    suspend fun insertFarmPhoto(
        farmId: Int,
        photoUri: String
    ) = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put("farmId", farmId)
            put("photoUri", photoUri)
        }

        db.writableDatabase.insertOrThrow(
            "farm_photos",
            null,
            values
        )
    }

    suspend fun getFarmPhotos(farmId: Int): List<String> =
        withContext(Dispatchers.IO) {
            val photos = mutableListOf<String>()

            db.readableDatabase.rawQuery(
                """
                SELECT photoUri FROM farm_photos
                WHERE farmId = ?
                ORDER BY photoId
                """.trimIndent(),
                arrayOf(farmId.toString())
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    photos.add(cursor.getString(0))
                }
            }

            photos
        }

    // =====================================
    // CROPS
    // =====================================

    suspend fun insertCrop(crop: Crop) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("farmId", crop.farmId)
                put("cropName", crop.cropName)
                put("cropVariety", crop.cropVariety)
                put("cropStatus", crop.cropStatus)
            }

            db.writableDatabase.insertOrThrow(
                "crops", null, values
            )
        }

    suspend fun getCrops(farmId: Int): List<Crop> =
        withContext(Dispatchers.IO) {
            val list = mutableListOf<Crop>()

            db.readableDatabase.rawQuery(
                "SELECT * FROM crops WHERE farmId = ?",
                arrayOf(farmId.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        Crop(
                            cropId = c.getInt(0),
                            farmId = c.getInt(1),
                            cropName = c.getString(2),
                            cropVariety = c.getString(3),
                            cropStatus = c.getString(4)
                        )
                    )
                }
            }

            list
        }

    suspend fun updateCrop(crop: Crop): Int =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("cropName", crop.cropName)
                put("cropVariety", crop.cropVariety)
                put("cropStatus", crop.cropStatus)
            }

            db.writableDatabase.update(
                "crops",
                values,
                "cropId = ?",
                arrayOf(crop.cropId.toString())
            )
        }

    suspend fun deleteCrop(cropId: Int) =
        withContext(Dispatchers.IO) {
            db.writableDatabase.delete(
                "crops", "cropId = ?",
                arrayOf(cropId.toString())
            )
        }

    // =====================================
    // PRODUCTION AREAS
    // =====================================

    suspend fun insertArea(area: ProductionArea) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("farmId", area.farmId)
                put("areaUnit", area.areaUnit)
                put("soilType", area.soilType)
                put("currentLandStatus", area.currentLandStatus)
            }

            db.writableDatabase.insertOrThrow(
                "production_areas", null, values
            )
        }

    suspend fun getAreas(farmId: Int): List<ProductionArea> =
        withContext(Dispatchers.IO) {
            val list = mutableListOf<ProductionArea>()

            db.readableDatabase.rawQuery(
                "SELECT * FROM production_areas WHERE farmId = ?",
                arrayOf(farmId.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        ProductionArea(
                            areaId = c.getInt(0),
                            farmId = c.getInt(1),
                            areaUnit = c.getString(2),
                            soilType = c.getString(3),
                            currentLandStatus = c.getString(4)
                        )
                    )
                }
            }

            list
        }

    suspend fun deleteArea(areaId: Int) =
        withContext(Dispatchers.IO) {
            db.writableDatabase.delete(
                "production_areas", "areaId = ?",
                arrayOf(areaId.toString())
            )
        }

    // =====================================
    // HARVEST RECORDS
    // =====================================

    suspend fun insertHarvest(harvest: Harvest) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("cropId", harvest.cropId)
                put("harvestDate", harvest.harvestDate)
                put("harvestQuality", harvest.harvestQuality)
                put("availableQuantity", harvest.availableQuantity)
            }

            db.writableDatabase.insertOrThrow(
                "harvests", null, values
            )
        }

    suspend fun getHarvests(farmId: Int): List<Harvest> =
        withContext(Dispatchers.IO) {
            val list = mutableListOf<Harvest>()

            db.readableDatabase.rawQuery(
                """
                SELECT h.* FROM harvests h
                INNER JOIN crops c ON h.cropId = c.cropId
                WHERE c.farmId = ?
                """.trimIndent(),
                arrayOf(farmId.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        Harvest(
                            harvestId = c.getInt(0),
                            cropId = c.getInt(1),
                            harvestDate = c.getString(2),
                            harvestQuality = c.getString(3),
                            availableQuantity = c.getDouble(4)
                        )
                    )
                }
            }

            list
        }

    suspend fun deleteHarvest(harvestId: Int) =
        withContext(Dispatchers.IO) {
            db.writableDatabase.delete(
                "harvests", "harvestId = ?",
                arrayOf(harvestId.toString())
            )
        }

    // =====================================
    // FARM BUSINESS
    // =====================================

    suspend fun insertBusiness(business: FarmBusiness) =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("farmId", business.farmId)
                put("cropName", business.cropName)
                put("quantitySold", business.quantitySold)
                put("price", business.price)
                put("expenses", business.expenses)
            }

            db.writableDatabase.insertOrThrow(
                "farm_business", null, values
            )
        }

    suspend fun getBusiness(farmId: Int): List<FarmBusiness> =
        withContext(Dispatchers.IO) {
            val list = mutableListOf<FarmBusiness>()

            db.readableDatabase.rawQuery(
                "SELECT * FROM farm_business WHERE farmId = ?",
                arrayOf(farmId.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        FarmBusiness(
                            businessId = c.getInt(0),
                            farmId = c.getInt(1),
                            cropName = c.getString(2),
                            quantitySold = c.getDouble(3),
                            price = c.getDouble(4),
                            expenses = c.getDouble(5)
                        )
                    )
                }
            }

            list
        }

    suspend fun deleteBusiness(businessId: Int) =
        withContext(Dispatchers.IO) {
            db.writableDatabase.delete(
                "farm_business", "businessId = ?",
                arrayOf(businessId.toString())
            )
        }

    suspend fun getTotalProfit(): Double =
        withContext(Dispatchers.IO) {
            db.readableDatabase.rawQuery(
                """
                SELECT SUM((quantitySold * price) - expenses)
                FROM farm_business
                WHERE farmId IN (SELECT id FROM farms WHERE isDeleted = 0)
                """.trimIndent(),
                null
            ).use { c ->
                if (c.moveToFirst() && !c.isNull(0)) {
                    c.getDouble(0)
                } else {
                    0.0
                }
            }
        }

    suspend fun updateArea(area: ProductionArea): Int =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("areaUnit", area.areaUnit)
                put("soilType", area.soilType)
                put("currentLandStatus", area.currentLandStatus)
            }

            db.writableDatabase.update(
                "production_areas",
                values,
                "areaId = ?",
                arrayOf(area.areaId.toString())
            )
        }

    suspend fun updateHarvest(harvest: Harvest): Int =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("cropId", harvest.cropId)
                put("harvestDate", harvest.harvestDate)
                put("harvestQuality", harvest.harvestQuality)
                put("availableQuantity", harvest.availableQuantity)
            }

            db.writableDatabase.update(
                "harvests",
                values,
                "harvestId = ?",
                arrayOf(harvest.harvestId.toString())
            )
        }

    suspend fun updateBusiness(business: FarmBusiness): Int =
        withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("cropName", business.cropName)
                put("quantitySold", business.quantitySold)
                put("price", business.price)
                put("expenses", business.expenses)
            }

            db.writableDatabase.update(
                "farm_business",
                values,
                "businessId = ?",
                arrayOf(business.businessId.toString())
            )
        }

    // =====================================
    // CROP AREAS (MAP BOUNDARIES)
    // =====================================

    private fun ensureBoundaryTable() {
        db.writableDatabase.execSQL(
            """
            CREATE TABLE IF NOT EXISTS crop_boundaries (
                cropId INTEGER PRIMARY KEY,
                points TEXT NOT NULL,
                FOREIGN KEY(cropId)
                REFERENCES crops(cropId) ON DELETE CASCADE
            )
            """.trimIndent()
        )
    }

    private fun parsePoints(text: String): List<Pair<Double, Double>> =
        text.split(";").mapNotNull {
            val part = it.split(",")
            val lat = part.getOrNull(0)?.toDoubleOrNull()
            val lon = part.getOrNull(1)?.toDoubleOrNull()

            if (lat != null && lon != null) Pair(lat, lon) else null
        }

    suspend fun saveBoundary(
        cropId: Int,
        points: List<Pair<Double, Double>>
    ) = withContext(Dispatchers.IO) {
        ensureBoundaryTable()

        val values = ContentValues().apply {
            put("cropId", cropId)
            put(
                "points",
                points.joinToString(";") { "${it.first},${it.second}" }
            )
        }

        db.writableDatabase.insertWithOnConflict(
            "crop_boundaries",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    suspend fun getBoundary(cropId: Int): List<Pair<Double, Double>> =
        withContext(Dispatchers.IO) {
            ensureBoundaryTable()

            db.readableDatabase.rawQuery(
                "SELECT points FROM crop_boundaries WHERE cropId = ?",
                arrayOf(cropId.toString())
            ).use { c ->
                if (c.moveToFirst()) parsePoints(c.getString(0))
                else emptyList()
            }
        }

    suspend fun deleteBoundary(cropId: Int) =
        withContext(Dispatchers.IO) {
            ensureBoundaryTable()

            db.writableDatabase.delete(
                "crop_boundaries",
                "cropId = ?",
                arrayOf(cropId.toString())
            )
        }

    suspend fun getBoundariesForFarm(farmId: Int): List<CropBoundary> =
        withContext(Dispatchers.IO) {
            ensureBoundaryTable()

            val list = mutableListOf<CropBoundary>()

            db.readableDatabase.rawQuery(
                """
                SELECT c.cropId, c.cropName, b.points
                FROM crop_boundaries b
                INNER JOIN crops c ON b.cropId = c.cropId
                WHERE c.farmId = ?
                """.trimIndent(),
                arrayOf(farmId.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        CropBoundary(
                            cropId = c.getInt(0),
                            cropName = c.getString(1),
                            points = parsePoints(c.getString(2))
                        )
                    )
                }
            }

            list
        }

    // =====================================
    // READ FARMS
    // =====================================

    private fun read(
        sql: String,
        args: Array<String>?
    ): List<Farm> {

        val list = mutableListOf<Farm>()

        db.readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) {
                list.add(
                    Farm(
                        id = c.getInt(0),
                        farmName = c.getString(1),
                        ownerName = c.getString(2),
                        farmAddress = c.getString(3),
                        contactNumber = c.getString(4),
                        latitude = c.getDouble(5),
                        longitude = c.getDouble(6),
                        farmPhoto = c.getString(7) ?: "",
                        website = c.getString(8) ?: ""
                    )
                )
            }
        }

        return list
    }
}