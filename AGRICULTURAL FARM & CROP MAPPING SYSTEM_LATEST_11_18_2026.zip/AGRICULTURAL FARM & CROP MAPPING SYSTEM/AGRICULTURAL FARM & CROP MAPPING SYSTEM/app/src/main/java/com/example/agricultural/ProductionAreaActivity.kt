
package com.example.agricultural

import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.agricultural.databinding.ActivityProductionAreaBinding
import kotlinx.coroutines.launch

class ProductionAreaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductionAreaBinding

    private val dao by lazy {
        AppDatabase.get(this).farmDao()
    }

    private var farmId = -1

    private var editingAreaId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityProductionAreaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        farmId = intent.getIntExtra("farm_id", -1)

        if (farmId <= 0) {
            Toast.makeText(this, "Invalid Farm ID", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSaveArea.setOnClickListener { saveArea() }

        loadAreas()
    }

    private fun saveArea() {
        val unit = binding.etAreaUnit.text.toString().trim()
        val soil = binding.etSoilType.text.toString().trim()
        val status = binding.etLandStatus.text.toString().trim()

        if (unit.isBlank() || soil.isBlank() || status.isBlank()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                if (editingAreaId > 0) {
                    dao.updateArea(
                        ProductionArea(
                            areaId = editingAreaId,
                            farmId = farmId,
                            areaUnit = unit,
                            soilType = soil,
                            currentLandStatus = status
                        )
                    )
                    editingAreaId = -1
                    binding.btnSaveArea.text = "＋ Save Area"
                } else {
                    dao.insertArea(
                        ProductionArea(
                            farmId = farmId,
                            areaUnit = unit,
                            soilType = soil,
                            currentLandStatus = status
                        )
                    )
                }
                binding.etAreaUnit.text.clear()
                binding.etSoilType.text.clear()
                binding.etLandStatus.text.clear()

                loadAreas()

                Toast.makeText(
                    this@ProductionAreaActivity,
                    "Production area saved!",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (e: Exception) {
                Toast.makeText(
                    this@ProductionAreaActivity,
                    "Save failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun loadAreas() {
        lifecycleScope.launch {
            try {
                val areas = dao.getAreas(farmId)
                binding.layoutAreaList.removeAllViews()

                if (areas.isEmpty()) {
                    val empty = TextView(this@ProductionAreaActivity)
                    empty.text = "No production areas registered yet."
                    empty.textSize = 15f
                    empty.gravity = Gravity.CENTER
                    empty.setTextColor(Color.GRAY)
                    empty.setPadding(20, 35, 20, 35)
                    binding.layoutAreaList.addView(empty)
                }

                areas.forEach { area ->
                    val card = LinearLayout(this@ProductionAreaActivity)
                    card.orientation = LinearLayout.VERTICAL
                    card.setPadding(20, 18, 20, 18)
                    card.setBackgroundColor(Color.rgb(240, 248, 240))

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 8, 0, 12)
                    card.layoutParams = params

                    val title = TextView(this@ProductionAreaActivity)
                    title.text = "Production Area"
                    title.textSize = 19f
                    title.setTypeface(null, Typeface.BOLD)
                    title.setTextColor(Color.rgb(35, 100, 55))
                    card.addView(title)

                    val unit = TextView(this@ProductionAreaActivity)
                    unit.text = "Area: ${area.areaUnit}"
                    unit.textSize = 15f
                    unit.setTextColor(Color.DKGRAY)
                    unit.setPadding(0, 8, 0, 0)
                    card.addView(unit)

                    val soil = TextView(this@ProductionAreaActivity)
                    soil.text = "Soil Type: ${area.soilType}"
                    soil.textSize = 15f
                    soil.setTextColor(Color.DKGRAY)
                    soil.setPadding(0, 5, 0, 0)
                    card.addView(soil)

                    val status = TextView(this@ProductionAreaActivity)
                    status.text = "Land Status: ${area.currentLandStatus}"
                    status.textSize = 15f
                    status.setTextColor(Color.DKGRAY)
                    status.setPadding(0, 5, 0, 12)
                    card.addView(status)

                    val delete = Button(this@ProductionAreaActivity)
                    delete.text = "Delete Area"

                    delete.setOnClickListener {
                        lifecycleScope.launch {
                            try {
                                dao.deleteArea(area.areaId)
                                loadAreas()

                                Toast.makeText(
                                    this@ProductionAreaActivity,
                                    "Area deleted",
                                    Toast.LENGTH_SHORT
                                ).show()

                            } catch (e: Exception) {
                                Toast.makeText(
                                    this@ProductionAreaActivity,
                                    "Delete failed: ${e.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }

                    val edit = Button(this@ProductionAreaActivity)
                    edit.text = "Edit Area"
                    edit.setOnClickListener {
                        editingAreaId = area.areaId
                        binding.etAreaUnit.setText(area.areaUnit)
                        binding.etSoilType.setText(area.soilType)
                        binding.etLandStatus.setText(area.currentLandStatus)
                        binding.btnSaveArea.text = "Update Area"
                    }
                    card.addView(edit)

                    card.addView(delete)
                    binding.layoutAreaList.addView(card)
                }

            } catch (e: Exception) {
                Toast.makeText(
                    this@ProductionAreaActivity,
                    "Loading failed: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && farmId > 0) {
            loadAreas()
        }
    }
}
