package com.example.agricultural

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.agricultural.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val dao by lazy {
        AppDatabase.get(this).farmDao()
    }

    private val adapter = FarmAdapter { farm ->
        val intent = Intent(this, FarmDetailsActivity::class.java)
        intent.putExtra("farm_id", farm.id)
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupButtons()
        setupSearch()
        setupBottomNavigation()
        insertSampleFarms()
    }
    private fun setupRecyclerView() {
        binding.rvFarms.layoutManager =
            LinearLayoutManager(this)

        binding.rvFarms.adapter = adapter
    }
    private fun setupButtons() {
        binding.btnAddFarm.setOnClickListener {
            startActivity(
                Intent(this, AddFarmActivity::class.java)
            )
        }

    }

    private fun setupSearch() {
        binding.etSearch.doAfterTextChanged {
            text -> val query = text?.toString()?.trim().orEmpty()

            loadFarms(query)
        }

    }
    private fun setupBottomNavigation() {

        binding.bottomNav.setOnItemSelectedListener { item ->

            when (item.itemId) {
                R.id.nav_home -> { loadFarms("")
                true
            }
                R.id.nav_farms -> { startActivity(Intent(this, FarmsActivity::class.java))
                    true
                }
                R.id.nav_map -> {startActivity(Intent(this, FarmMapActivity::class.java))
                    true
                }
                R.id.nav_reports -> {startActivity(Intent(this, ReportsActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
    private fun insertSampleFarms() {

        lifecycleScope.launch { if (dao.count() == 0) {

                dao.insert(
                    Farm(
                        farmName = "Juan's Mango Farm",
                        ownerName = "Juan Dela Cruz",
                        farmAddress = "Nasugbu, Batangas",
                        contactNumber = "09123456789",
                        latitude = 14.0667,
                        longitude = 120.6333
                    )
                )
                dao.insert(
                    Farm(
                        farmName = "Mang Tomas' Farm",
                        ownerName = "Mang Tomas",
                        farmAddress = "Nasugbu, Batangas",
                        contactNumber = "09123456780",
                        latitude = 14.0700,
                        longitude = 120.6300
                    )
                )

                dao.insert(
                    Farm(
                        farmName = "Loli's Banana Farm",
                        ownerName = "Loli",
                        farmAddress = "Nasugbu, Batangas",
                        contactNumber = "09123456781",
                        latitude = 14.0600,
                        longitude = 120.6400
                    )
                )
            }
            loadFarms("")
        }
    }

    private fun loadFarms(query: String) {

        lifecycleScope.launch {

            val farms = if (query.isBlank()) {
                dao.getAll()
            } else {
                dao.search(query)
            }

            adapter.submitList(farms)

            binding.tvFarmCount.text =
                "${farms.size} Farms"
        }
    }

    override fun onResume() {
        super.onResume()

        if (::binding.isInitialized) {
            loadFarms(
                binding.etSearch.text?.toString()
                    .orEmpty().trim()
            )
        }
    }
}
