package com.example.agricultural

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.CopyrightOverlay

class FarmMapActivity : AppCompatActivity() {

    private lateinit var mapView: org.osmdroid.views.MapView

    private val dao by lazy {
        AppDatabase.get(this).farmDao()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().apply {
            userAgentValue =
                "AgriFarm/1.0 (contact: your-real-email@example.com)"

            osmdroidBasePath = getExternalFilesDir(null)
            osmdroidTileCache = getExternalFilesDir("tiles")
        }

        setContentView(R.layout.activity_farm_map)

        mapView = findViewById(R.id.mapView)
        mapView.overlays.add(CopyrightOverlay(this))

        // OpenStreetMap standard tile source
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)

        // Nasugbu, Batangas
        val startPoint = GeoPoint(14.0667, 120.6333)

        mapView.controller.setZoom(13.0)
        mapView.controller.setCenter(startPoint)

        findViewById<android.widget.Button>(R.id.btnBack)
            .setOnClickListener {
                finish()
            }

        loadFarmMarkers()
    }
    private fun loadFarmMarkers() {

        lifecycleScope.launch {

            val farms = dao.getAll()

            mapView.overlays.removeAll { it is Marker }

            for (farm in farms) {
                val marker = Marker(mapView)

                marker.position = GeoPoint(
                    farm.latitude,
                    farm.longitude
                )

                marker.title = farm.farmName

                marker.snippet =
                    "Owner: ${farm.ownerName}\n" +
                            "Address: ${farm.farmAddress}"

                mapView.overlays.add(marker)
            }

            mapView.invalidate()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::mapView.isInitialized) {
            mapView.onResume()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::mapView.isInitialized) {
            mapView.onPause()
        }
    }
}
