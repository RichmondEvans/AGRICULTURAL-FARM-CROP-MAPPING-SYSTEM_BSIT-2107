
package com.example.agricultural

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.agricultural.databinding.ActivityCropsBinding
import kotlinx.coroutines.launch

class CropsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCropsBinding
    private val dao by lazy { AppDatabase.get(this).farmDao() }
    private var farmId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCropsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        farmId = intent.getIntExtra("farm_id", -1)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnSaveCrop.setOnClickListener { saveCrop() }

        loadCrops()
    }

    private fun saveCrop() {
        val name = binding.etCropName.text.toString()
        val variety = binding.etCropVariety.text.toString()
        val status = binding.etCropStatus.text.toString()

        if (name.isBlank() || variety.isBlank() || status.isBlank()) {
            Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            dao.insertCrop(
                Crop(
                    farmId = farmId,
                    cropName = name,
                    cropVariety = variety,
                    cropStatus = status
                )
            )

            binding.etCropName.text.clear()
            binding.etCropVariety.text.clear()
            binding.etCropStatus.text.clear()

            loadCrops()
            Toast.makeText(this@CropsActivity, "Crop saved", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadCrops() {
        lifecycleScope.launch {
            val crops = dao.getCrops(farmId)
            binding.layoutCropList.removeAllViews()

            crops.forEach { crop ->
                val item = TextView(this@CropsActivity)
                item.text = "${crop.cropName} - ${crop.cropVariety} - ${crop.cropStatus}"
                item.textSize = 16f
                binding.layoutCropList.addView(item)

                val delete = Button(this@CropsActivity)
                delete.text = "Delete"
                delete.setOnClickListener {
                    lifecycleScope.launch {
                        dao.deleteCrop(crop.cropId)
                        loadCrops()
                    }
                }

                binding.layoutCropList.addView(delete)
            }
        }
    }
}
